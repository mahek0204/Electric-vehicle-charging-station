<?php
setcookie("userid","",time() -0,"/");
setcookie("username","",time() -0,"/");
header("location: /efuelwebsite");
?>