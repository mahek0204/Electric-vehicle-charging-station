<?php
  
require("connection.php");
$errorMessage="";
if(isset($_POST["submit"]))
{

    $uemail = $_POST["useremail"];
    $pwd = $_POST["password"];
    $uname=$_POST["username"];
    $ucontactNo=$_POST["usercntc"];

    $checkEmailQuery = "SELECT * from ef_usermaster WHERE um_email='$uemail'";
    $checkEmailResult = mysqli_query($conn,$checkEmailQuery);
    $isEmail = mysqli_num_rows($checkEmailResult);

    $checkContactQuery = "SELECT * from ef_usermaster WHERE um_contactNo='$ucontactNo'";
    $checkContactResult = mysqli_query($conn,$checkContactQuery);
    $isContact = mysqli_num_rows($checkContactResult);
    if($isEmail==1)
    {
        $errorMessage = "Already loged in with this Email..!";
    }
    else if($isContact==1)
    {
        $errorMessage = "Already loged in with this contact number..!!";
    }
    else{
        $errorMessage = "Registration successful !!";
    }
    if($isEmail==0 && $isContact==0)
    {
        $query="insert into ef_usermaster (um_email,um_password,um_name,um_contactNo) values ('$uemail','$pwd','$uname',$ucontactNo)";
    
        $result= mysqli_query($conn,$query);
       
        header("Location: index.php");
    }
    else{
        $errorMessage="Contact No or Email is already exist";
    }
   
    /*if($nRows==1)
    {
        $useremail= $data['um_email'];
        $userpass= $data['um_password'];
        
        echo $useremail, "-" , $userpass;
        setcookie('username',$useremail,time()+86400*1,'/');
        setcookie('userpass',$userpass,time()+86400*1,'/');
        
    }*/
}
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="image/f213.png" />
		
        <title>E Fuel</title>

		<link rel="stylesheet" href="/Dashboard/css/font-awesome.min.css" />

        <link href="login/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="login/css/style.css" rel="stylesheet" type="text/css" />
		
    </head>

<body class="fixed-left">

		<div class="row">
		
			<div class="col-md-12" >
			
				<div class="card-box lgn">
				
					<center>
						<img src="images\logo.png" class="img-responsive login-logo">
					</center>

                    <!--<form action="forms/login.php" method="post" class="php-email-form" data-aos="fade-up" data-aos-delay="200" form role="form">-->
                    <form role="form" class="row" method="post">
                                        
						    <div class="form-group col-md-12">
                                <label for="exampleInputEmail1">Name</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="username" placeholder="Enter your name">       
                            </div>

                            <div class="form-group col-md-12">
                                <label for="exampleInputPassword1">Email I'd</label>
                                <input type="text" class="form-control" id="exampleInputPassword1" name="useremail" placeholder="Enter your Email I'd">
                            </div>

                            <div class="form-group col-md-12">
                                <label for="exampleInputPassword1">Password</label>
                                <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Enter Password">
                            </div>

                            <div class="form-group col-md-12">
                                <label for="exampleInputPassword1">contact No.</label>
                                <input type="number" class="form-control" id="exampleInputPassword1" name="usercntc" placeholder="Enter your contact No.">
                            </div>

							<!--<div>
							    <a href="#">Forgot Password ?</a>
						        </div><br><br>-->

                            <!--<p class="text-danger">
                                
                            
                                /*if(isset($nRows))
                                {
                                    if($nRows==0)
                                        {
                                            echo "Invalid credentials !!";
                                        }
                                }
                            
                                ?>*/
						<p>
						    <div class="form-control">
                             <a href="dbindex.php" class="btn btn-logo btn-block btn-lg">Login</a> -->
                           <p class="text-danger"><?php echo $errorMessage; ?></p>
                             <button name="submit" class="btn btn-logo btn-block btn-lg">Sign Up</button>
                             <p>Already have an account ? <a href="login.php">Login</a></p>
                        
                            </div>	
						
					</form>
                </div>
			
			</div>
		
		</div>

        <script src="login/js/jquery.min.js"></script>
        <script src="login/js/popper.min.js"></script><!-- Popper for Bootstrap -->
        <script src="login/js/bootstrap.min.js"></script>
        <script src="login/js/jquery.slimscroll.js"></script>
        <script src="login/js/waves.js"></script>
        <script src="login/js/jquery.nicescroll.js"></script>
        <script src="login/js/jquery.scrollTo.min.js"></script>
        <script src="login/js/jquery.app.js"></script>
	
		
	
    </body>
</html>