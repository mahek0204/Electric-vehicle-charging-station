<?php
include("header.php");
require "connection.php";

$book="SELECT bm_id from ef_bookingmaster";
$bookresult=mysqli_query($conn,$book);
$bdata=mysqli_num_rows($bookresult);

$count="SELECT pm_pumpname from ef_pumpmaster";
$result1=mysqli_query($conn,$count);
$data1=mysqli_num_rows($result1);

$tbQuery1 = "SELECT * FROM ef_feedbackmaster WHERE fm_status='1'";
$tbResult1 = mysqli_query($conn,$tbQuery1);
$totalCompleted = mysqli_num_rows($tbResult1);

$totalfeed = "SELECT fm_status FROM ef_feedbackmaster ";
$totalre = mysqli_query($conn,$totalfeed);
$totaldata = mysqli_num_rows($totalre);

$pumpQuery = "SELECT * FROM ef_pumpmaster";
$pumpResult = mysqli_query($conn,$pumpQuery);
//$pumpData = mysqli_fetch_assoc($pumpResult);
$data=[];

$iquery="SELECT * FROM ef_pointmaster
INNER JOIN ef_levelmaster on ef_pointmaster.lm_id = ef_levelmaster.lm_id
INNER JOIN ef_pumpmaster on ef_pumpmaster.pmId = ef_pointmaster.pm_id";
$iresult=mysqli_query($conn,$iquery);


while($row = mysqli_fetch_array($pumpResult))
{
  $data[]=$row;
}

$query="select * from ef_feedbackmaster where fm_status=1";
$result=mysqli_query($conn,$query);



?>
  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section dark-background">

      <img src="assets/img/world-dotted-map.png" alt="" class="hero-bg" data-aos="fade-in">

      <div class="container">
        <div class="row gy-4 d-flex justify-content-between">
          <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
            <h2 data-aos="fade-up"> Charge up, drive on, and make Mother Earth smile</h2>
            <p data-aos="fade-up" data-aos-delay="100">
            Electric vehicles are on the rise, and so is the need for convenient charging solutions.
Charge with ease at our new electric vehicle charging point. Plug in, charge up, and hit the road, all while reducing your carbon footprint.
Curious? Visit our installation today and experience the future of sustainable travel.
            </p>

            <div class="row gy-4" data-aos="fade-up" data-aos-delay="300">

              <div class="col-lg-3 col-6">
                <div class="stats-item text-center w-100 h-100">
                  <span data-purecounter-start="0" data-purecounter-end="<?php echo $bdata ?>" data-purecounter-duration="0" class="purecounter"></span>
                  <p>Registrations</p>
                </div>
              </div><!-- End Stats Item -->

              <div class="col-lg-3 col-6">
                <div class="stats-item text-center w-100 h-100">
                  <span data-purecounter-start="0" data-purecounter-end="<?php echo $data1 ?>" data-purecounter-duration="0" class="purecounter"></span>
                  <p>Pumps</p>
                </div>
              </div><!-- End Stats Item -->

              <div class="col-lg-3 col-6">
                <div class="stats-item text-center w-100 h-100">
                  <span data-purecounter-start="0" data-purecounter-end="<?php echo $totalCompleted ?>" data-purecounter-duration="0" class="purecounter"></span>
                  <p>Happy Clients</p>
                </div>
              </div><!-- End Stats Item -->

              <div class="col-lg-3 col-6">
                <div class="stats-item text-center w-100 h-100">
                  <span data-purecounter-start="0" data-purecounter-end="<?php echo $totaldata ?>" data-purecounter-duration="0" class="purecounter"></span>
                  <p>Reviews</p>
                </div>
              </div><!-- End Stats Item -->

            </div>

          </div>

          <div class="col-lg-5 order-1 order-lg-2 hero-img" data-aos="zoom-out">
            <img src="assets/img/hero-img.svg" class="img-fluid mb-3 mb-lg-0" alt="">
          </div>

        </div>
      </div>

    </section>
    
    <!-- /Hero Section -->

<br><br><br>   
    <div class="row gy-4" data-aos="fade-up" data-aos-delay="300">              
										<?php
										while($d=mysqli_fetch_array($iresult))
										{
											?>
              <div class="col-lg-3 col-6">
                <div class="stats-item text-center w-100 h-100">
                  <!--<span data-purecounter-start="0" data-purecounter-end="" data-purecounter-duration="0" class="purecounter"></span>-->
                  <p><?php echo $d['pm_pumpname']; ?></p>
                  
                   <img src="http://localhost/efueladmin/logo/<?php echo $d['pm_image']; ?>">
                   <p><?php echo $d['lm_name'];?></p>
                </div>
              </div>
                    
									  <?php
										  }
									  ?>


     <!--Featured Services Section--> 
    <section id="featured-services" class="featured-services section">

      <div class="container">
<div class="row gy-4">
 
<div id="map" style="height: 500px; width: 100%;"></div>
</div>
 <br>
      
<div class="row gy-4" data-aos="fade-up" data-aos-delay="300">


    <!-- About Section -->
    <section id="about" class="about section">

      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-5 position-relative align-self-start order-lg-last order-first" data-aos="fade-up" data-aos-delay="200">
            <img src="images/about1.jpg" class="img-fluid" alt="">
            <!--<a href="https://www.youtube.com/watch?v=Y7f98aduVJ8" class="glightbox pulsating-play-btn"></a>-->
          </div>

          <div class="col-lg-6 content order-last  order-lg-first" data-aos="fade-up" data-aos-delay="100">
            <h3>About Us</h3>
            <p>
            At our E Fuel pump, we are passionate about powering the future of transportation. Founded with a vision to accelerate the adoption of electric vehicles, we specialize in innovative charging solutions designed to meet the needs of both urban and rural communities.
            </p>
            <ul>
              <li>
                <i class="bi bi-menu-button-wide-fill"></i>
                <div>
                  <h5>Easy Online Booking</h5>
                  <p>Reserve your charging slot effortlessly through our user-friendly platform.</p>
                </div>
              </li>
              <li>
                <i class="bi bi-geo-alt"></i>
                <div>
                  <h5>Convenience First</h5>
                  <p>Our platform offers a user-friendly interface that allows you to find, book, and manage charging sessions in real time.</p>
                </div>
              </li>
              <li>
                <i class="bi bi-chat-square-heart"></i>
                <div>
                  <h5>Customer-Centric Approach</h5>
                  <p>We prioritize your experience, ensuring reliable and accessible charging options.
                  </p>
                </div>
              </li>
            </ul>
          </div>

        </div>

      </div>

    </section><!-- /About Section -->

    <!-- Services Section -->
    <section id="services" class="services section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <span>Charging Levels<br></span>
        <h2>Charging Levels</h2>
        <p>Electric vehicles can be charged using different levels of electric vehicle service equipment.</p>
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="card">
              
              <div class="card-img">
                <img src="images/level1.png" alt="" style="width:100%;" class="img-fluid">
              </div>
              <h3><a href="#" class="stretched-links">Level 1</a></h3>
              <p>Level 1 electric vehicle charging refers to the slowest charging option,
                 using a standard 120-volt household outlet, similar to a regular wall plug, 
                 to charge an electric vehicle battery overnight, providing only a few miles of range per hour of charge.</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="card">
              <div class="card-img">
                <img src="images/level2.png" alt="" style="width: 100%;" class="img-fluid">
              </div>
              <h3><a href="#" class="stretched-link">Level 2</a></h3>
              <p>A Level 2 electric vehicle charger is a mid-range charging option that provides significantly faster charging than Level 1, typically using a 240-volt power source,
                 it can usually charge most EVs to 80% capacity in 4-10 hours depending on the vehicle and charger power output. </p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="card">
              <div class="card-img">
                <img src="images/level3.png" alt="" style="width: 100%;" class="img-fluid">
              </div>
              <h3><a href="#" class="stretched-link">Level 3</a></h3>
              <p>A Level 3 electric vehicle charger, also known as a DC Fast Charger, 
                is the fastest type of EV charging, delivering high power directly to the vehicle's battery,
                allowing for quick recharges in a matter of minutes.</p>
            </div>
          </div>
          

        </div>

      </div>

    </section><!-- /Services Section -->

    <!-- Call To Action Section -->
    <section id="call-to-action" class="call-to-action section dark-background">

      <img src="images/email.jpg" alt="">

      <div class="container">
        <div class="row justify-content-center" data-aos="zoom-in" data-aos-delay="100">
          <div class="col-xl-10">
            <div class="text-center">
              <h3>Contact Us</h3>
              <p>You can fill out a form to get more information about their electric charging services.</p>
              <a class="cta-btn" href="contact.php">Click Here</a>
            </div>
          </div>
        </div>
      </div>

    </section><!-- /Call To Action Section -->

    <!-- Features Section -->
    <section id="features" class="features section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <span>Features</span>
        <h2>Features</h2>
        <!--<p>Necessitatibus eius consequatur ex aliquid fuga eum quidem sint consectetur velit</p>-->
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row gy-4 align-items-center features-item">
          <div class="col-md-5 d-flex align-items-center" data-aos="zoom-out" data-aos-delay="100">
            <img src="images/chargingspeed.png" class="img-fluid" alt="">
          </div>
          <div class="col-md-7" data-aos="fade-up" data-aos-delay="100">
            <h3>Charging speed</h3>
            <p class="fst-italic">
            
              DC fast chargers are the fastest charging option, and can add hundreds of miles of range in 20–30 minutes. However, they're usually more expensive than level 1 and 2 chargers, which are cheaper if you have more time to charge. 
            </p>
            <!--
            <ul>
              <li><i class="bi bi-check"></i><span> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</span></li>
              <li><i class="bi bi-check"></i> <span>Duis aute irure dolor in reprehenderit in voluptate velit.</span></li>
              <li><i class="bi bi-check"></i> <span>Ullam est qui quos consequatur eos accusamus.</span></li>
            </ul> -->
          </div>
        </div><!-- Features Item -->

        <div class="row gy-4 align-items-center features-item">
          <div class="col-md-5 order-1 order-md-2 d-flex align-items-center" data-aos="zoom-out" data-aos-delay="200">
            <img src="images/chargingtype.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 order-2 order-md-1" data-aos="fade-up" data-aos-delay="200">
            <h3>Charging type</h3>
            <p class="fst-italic">
            
            Level 2 chargers are the most common type of public EV charger, and are used in homes, businesses, and public parking. They deliver alternating current (AC) and can charge a typical EV battery overnight.
            </p>
            <!--<p>
              Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
              velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
              culpa qui officia deserunt mollit anim id est laborum
            </p>-->
          </div>
        </div><!-- Features Item -->

        <div class="row gy-4 align-items-center features-item">
          <div class="col-md-5 d-flex align-items-center" data-aos="zoom-out">
            <img src="images/chargeloc.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7" data-aos="fade-up">
            <h3>Charging location</h3>
            <p>
            Public charging stations are often found in workplaces, businesses, malls, and hotels. </p>
            <!--<ul>
              <li><i class="bi bi-check"></i> <span>Ullamco laboris nisi ut aliquip ex ea commodo consequat.</span></li>
              <li><i class="bi bi-check"></i><span> Duis aute irure dolor in reprehenderit in voluptate velit.</span></li>
              <li><i class="bi bi-check"></i> <span>Facilis ut et voluptatem aperiam. Autem soluta ad fugiat</span>.</li>
            </ul>-->
          </div>
        </div><!-- Features Item -->

        <div class="row gy-4 align-items-center features-item">
          <div class="col-md-5 order-1 order-md-2 d-flex align-items-center" data-aos="zoom-out">
            <img src="images/loadmanage.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-md-7 order-2 order-md-1" data-aos="fade-up">
            <h3>Load management</h3>
            <p class="fst-italic">
            
            This feature allows multiple electric vehicles to charge at the same time by automatically distributing the available power. This can help prevent power peaks and increase in power prices. 
            </p>
           <!-- <p>
              Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
              velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
              culpa qui officia deserunt mollit anim id est laborum
            </p> -->
          </div>
        </div><!-- Features Item -->

      </div>

    </section><!-- /Features Section -->

    <!-- Pricing Section -->
    <section id="pricing" class="pricing section">

      

        </div>

      </div>

    </section><!-- /Pricing Section -->

    <!-- Testimonials Section -->
    <section id="testimonials" class="testimonials section dark-background">

      <img src="images/feedback.png" class="testimonials-bg" alt="">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="swiper init-swiper">
          <script type="application/json" class="swiper-config">
            {
              "loop": true,
              "speed": 600,
              "autoplay": {
                "delay": 5000
              },
              "slidesPerView": "auto",
              "pagination": {
                "el": ".swiper-pagination",
                "type": "bullets",
                "clickable": true
              }
            }
          </script>
          <div class="swiper-wrapper">

         <?php
          while($r = mysqli_fetch_array($result))
          {
            ?>
               <div class="swiper-slide">
              <div class="testimonial-item">
                <span class="testimonial-img text-primary fw-bold" style="display:block;border:1px solid grey;border-radius:50%;background:white;height:80px;width:80px;font-size:50px">
                  <?php
                  $name = str_split($r['fm_name'],1);
                  echo strtoupper($name[0]);
                  //$title = strtoupper($name[0]);
                  //echo $title; 
                  ?>
                </span>
                <!-- <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt=""> -->
                <h3><?php echo $r['fm_name']; ?></h3>
                <h4><?php echo $r['fm_profession']; ?></h4>
                
                <p>
                  <i class="bi bi-quote quote-icon-left"></i>
                  <span>
                    <?php echo $r['fm_message']; ?>
                  </span>
                  <i class="bi bi-quote quote-icon-right"></i>
                  
                
              </div>
            </div><!-- End testimonial item -->
            <?php
          }
         ?>

           

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>

    </section><!-- /Testimonials Section -->

    <!-- Faq Section -->
    <section id="faq" class="faq section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <span>Frequently Asked Questions</span>
        <h2>Frequently Asked Questions</h2>
        
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row justify-content-center">

          <div class="col-lg-10">

            <div class="faq-container">

              <div class="faq-item faq-active" data-aos="fade-up" data-aos-delay="200">
                <i class="faq-icon bi bi-question-circle"></i>
                <h3>How long does it take to charge my EV?
                </h3>
                <div class="faq-content">
                  <p>Charging time varies by the pump type, battery size, and charge level. Level 1 can take several hours, while Level 2 can take a few hours, and DC fast chargers can provide an 80% charge in around 30 minutes.</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div><!-- End Faq item-->

              <div class="faq-item" data-aos="fade-up" data-aos-delay="300">
                <i class="faq-icon bi bi-question-circle"></i>
                <h3>Do I need a special outlet for my charging pump?<h3>
                <div class="faq-content">
                  <p>
Level 1 chargers typically use standard outlets, while Level 2 chargers require a dedicated 240V outlet.</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div><!-- End Faq item-->

              <div class="faq-item" data-aos="fade-up" data-aos-delay="400">
                <i class="faq-icon bi bi-question-circle"></i>
                <h3>Can I charge multiple EVs with one pump?</h3>
                <div class="faq-content">
                  <p>Some charging pumps have multiple ports, but most are designed for single-vehicle charging. Look for multi-port models if needed.</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div><!-- End Faq item-->

              <div class="faq-item" data-aos="fade-up" data-aos-delay="500">
                <i class="faq-icon bi bi-question-circle"></i>
                <h3>What should I do if my charging pump is not working?<h3>
                <div class="faq-content">
                  <p>
Check the power supply, connections, and circuit breakers. If issues persist, consult the user manual or contact customer support.</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div><!-- End Faq item-->

              <div class="faq-item" data-aos="fade-up" data-aos-delay="600">
                <i class="faq-icon bi bi-question-circle"></i>
                <h3>Can I use my charging pump in different countries?</h3>
                <div class="faq-content">
                  <p>
Charging pumps may have different voltage and connector standards. Ensure compatibility with local requirements.</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div><!-- End Faq item-->

            </div>

          </div>

        </div>

      </div>

    </section><!-- /Faq Section -->

  </main>
  <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCXymo3Nv1M1cR9Ui44XA74I1imk4PVc64"></script>
  <script>
        function initMap() {
            // Center of the map
            var locations = <?php echo json_encode($data); ?>;
            var first = locations[0];
          
            var mapCenter = {lat: parseFloat(first.pm_lat), lng: parseFloat(first.pm_long)}; // Default center (e.g., San Francisco)

            // Create a map object
            var map = new google.maps.Map(document.getElementById('map'), {
                zoom: 10,
                center: mapCenter
            });

               // Create an InfoWindow
    var infoWindow = new google.maps.InfoWindow();
            
            // Loop through locations and place markers
            locations.forEach(function(location) {
              
                var marker = new google.maps.Marker({
                    position: {lat: parseFloat(location.pm_lat), lng: parseFloat(location.pm_long)},
                    map: map,
                    title: location.pm_pumpname,
                    title: location.pm_status,
                    icon :'/efuelwebsite/images/marker1.png'
                });
                var locationLink = "/efuelwebsite/detail.php?id="+location.pmId;
                // Add a click event listener to open the InfoWindow
        marker.addListener('click', function() {
            infoWindow.setContent('<div><h5>' + location.pm_pumpname + '</h5><br>' + 
                                   '<a class="btn btn-sm btn-primary" href='+locationLink+' target="blank">Details</a></div>');
            infoWindow.open(map, marker);
        });

            });

           
        }
    </script>
  <?php
   include("footer.php");
  ?>

  