<?php
require("connection.php");
$deleteId = $_GET['id'];
$query="DELETE FROM ef_bookingmaster WHERE bm_id=$deleteId";
$result=mysqli_query($conn,$query);
header("location: profile.php");
?>