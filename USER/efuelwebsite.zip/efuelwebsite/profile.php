<?php
require("connection.php");
$id = $_COOKIE["userid"];


if(isset($_POST["submit"]))
{

    $uemail = $_POST["useremail"];
    $uname=$_POST["username"];
    $ucontactNo=$_POST["usercntc"];

    $Query1 = "UPDATE ef_usermaster SET um_name='$uname',um_email='$uemail',um_contactNo='$ucontactNo' where um_id=$id";
    $getdata1 = mysqli_query($conn,$Query1);
    

    if($getdata1==1)
    {
        $username= $uname;
       
       
        setcookie('username',$username,time()+86400*1,'/');
        
        //header("Location: index.php");
    }
}
$query="SELECT * from ef_usermaster where um_id=$id";
$Result=mysqli_query($conn,$query);
$getdata=mysqli_fetch_array($Result);

//$bquery="INSERT into ef_creditmaster(um_id,bm_id) select um_id,bm_id from ef_bookingmaster where bm_status='Completed'";
// $cquery="INSERT into ef_creditmaster(cm_creditpoint) values (30)";
// $n=mysqli_query($conn,$cquery);
// $m=mysqli_fetch_array($n);


$bId=$_COOKIE['userid'];
$bookingQuery="select * from ef_bookingmaster where um_id=$bId";
$bookingResult=mysqli_query($conn,$bookingQuery);

// if(isset($_POST['btnCB'])){
//         $iquery="INSERT into ef_creditmaster(um_id,bm_id) select um_id,bm_id from ef_bookingmaster where bm_status='Completed'";
//         // $result=mysqli_query($conn,$iquery);
//         $result=mysqli_num_rows($iquery);
//         if($result==3){
//          $cquery="INSERT into ef_creditmaster (cm_creditpoint) values 30";
//           $result=mysqli_query($conn,$cquery);
//         }
//       }

//    $squery="SELECT * from ef_bookingmaster where bm_status='Completed'";
//     $result1=mysqli_query($conn,$squery);

// $fdata=mysqli_fetch_array($result1);  

 $cquery="SELECT * from ef_creditmaster where um_id=$id ";
 $result1=mysqli_query($conn,$cquery);
//  $count=mysqli_num_rows($result1);
//  if($count=3){
//     $insert="INSERT into ef_creditmaster(cm_creditpoint) values (30)";
//     $iresult=mysqli_query($conn,$insert);
//     $fdata=mysqli_fetch_array($iresult);

//  }
 

 

      
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">
        <link href="assets/img/f213.png" rel="icon">
        
		
        <title>E Fuel</title>

		<link rel="stylesheet" href="/Dashboard/css/font-awesome.min.css" />

        <link href="login/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="login/css/style.css" rel="stylesheet" type="text/css" />
		<style>
            .menulist{
                list-style-type: none;
                padding:4px;
                width:380px;
                background-color:white;
                
            }
            .menulist li{
                padding:15px 20px;
                
                font-size:17px;
                cursor: pointer;
                
            }
            .menulist li a{text-decoration:none;color:black;}

            #toastBox{
  position:absolute;
  bottom:30px;
  right:30px;
  display:flex;
  align-items:flex-end;
  flex-direction:column;
  overflow:hidden;
  padding:20px;
}

.toast{
  width:400px;
  height: 80px;
  background:#fff;
  font-weight:500;
  margin:15px,0; 
  box-shadow: 0 0 20px rgba(0,0,0,0.3);
  align-items:center;
  display:flex;
  position:relative;
  transform:translateX(100%);
  animation: moveleft 0.5s linear forwards;
}
@keyframes moveleft {
    100%{
        transform:translateX(0);
    }
}

.toast::after{
    content:'';
    position:absolute;
    left:0;
    bottom:0;
    width:100%;
    height:5px;
    background:green;
    animation:anim 5s linear forwards;
}

@keyframes anim{
    100%{
        width:0;

    }
}
        </style>
    </head>

<body class="fixed-left"  >

		<div class="row">
            <div class="col-md-2" style="height:100vh;">
                    <center> 
						<img src="images\logo.png" class="img-responsive login-logo" style="height:120px;width:230px;">
                        <!--<hr class="" style="display:block;border:3px solid #337ab7">-->
                    </center>
                <ul class="menulist"><b>
                    <li class="text-primary" onclick="show('profile');"><i class="fa fa-user"></i> Profile</li>
                    <li class="text-primary" onclick="show('booking');"><i class="fa fa-calendar"></i> My Bookings</li>
                    <li class="text-primary" onclick="gotoHome();"><i class="fa fa-home"></i> Back to Home</li>
                    
        </b>
                </ul>
               <!-- <hr class="" style="display:block;border:3px solid #337ab7">-->
            </div>
            <div class="col-md-10 bg-primary" id="booking" style="display:none;height:100vh;">
               <div class="container p-5">
                <div class="row" style="padding:5px;margin-top:10px;">
                    <h2 style="margin-bottom:10px;">My Bookings</h2>
                    <?php
                    while($row = mysqli_fetch_array($bookingResult))
                    {
                        ?>
                        <div class="col-md-3 card" style="border:1px solid grey;">
                       <div class="row">
                        <div class="col-md-6">
                        <h4><?php echo $row['bm_date']; ?></h4>
                        </div>
                        
                        <div class="col-md-6">
                        <h4><?php echo $row['bm_time']; ?></h4>
                        </div>
                        <div class="col-md-6">
                        <h4><?php echo $row['bm_vehicleNo']; ?></h4>
                        </div>
                        
                        
                        <div class="col-md-6">
                        <h4><?php echo $row['bm_status']; ?></h4>
                        </div>

                        <div class="col-md-6">
                        <button class="btn btn-primary" onclick="showToast(successMsg)" name="submitbtn" >Submit</button>
                        <div id="toastBox"></div>
                        </div>
                        
                        <a href="delete.php?id=<?php echo $row['bm_id']; ?>" onclick="return confirm('Are you sure you want to delete ?');"> 
                            <?php 
                            if($row['bm_status']=='Booked')
                        {
                            ?>
                            <div class="btn btn-danger btn-sm">Cancel</div>
                            <?php
                        }
                        ?>
                        </a>
                       </div>
                       
                       
                       
                    </div>
                        <?php
                    }
                    ?>
                    
                    <?php
                        while($fdata = mysqli_fetch_array($result1))
                    {
                        ?>
                    
                       <div class="col-md-6">
                        <h4><?php echo $fdata['cm_creditpoint']; ?></h4>
                        </div>
                        <?php
                    }
                    ?>

                </div>
               </div>
            </div>
            
			<div class="col-md-10 "class="bg"
                    style="background-image: url(images/chargeloc.jpg); background-size: cover; background-position: center;"  id="profile" style="height:100vh;">
            
			
				<div class="card-box lgn" style="padding:40px;">
				
					<center>
                    <h1 class="text-primary fw-bold">Update Your <br> Profile</h1>
                    <hr class="" style="display:block;border:1px solid #007bff">
						<!-- <img src="images\logo.png" class="img-responsive login-logo"> -->
					</center>

                    <!--<form action="forms/login.php" method="post" class="php-email-form" data-aos="fade-up" data-aos-delay="200" form role="form">-->
                    <form role="form" class="row" method="post">
                                        
						    <div class="form-group col-md-12">
                                <label for="exampleInputEmail1" class="text-primary">Name</label>
                                <input type="text" value="<?php echo $getdata['um_name']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" <?php echo $_COOKIE['username']; ?> name="username" placeholder="Enter your name">       
                            </div>

                            <div class="form-group col-md-12">
                                <label for="exampleInputPassword1" class="text-primary">Email I'd</label>
                                <input type="text" value="<?php echo $getdata['um_email']; ?>" class="form-control" id="exampleInputPassword1" name="useremail" placeholder="Enter your Email I'd">
                            </div>

                            <div class="form-group col-md-12">
                                <label for="exampleInputPassword1" class="text-primary">contact No.</label>
                                <input type="number" class="form-control" value="<?php echo $getdata['um_contactNo']; ?>" id="exampleInputPassword1" name="usercntc" placeholder="Enter your contact No.">
                            </div>

							
                          <?php
                          if(isset($getdata1))
                          {
                            if($getdata1==1)
                          {
                            echo "<p class='text-success'>Profile Update Successfully</p>";
                          }
                          }
                          
                          ?>
                             <div class="form-group col-md-12">
                             <button name="submit" class="btn btn-logo btn-block btn-md">Update Profile</button>
                             </div>
                        
                            </div>	
						
					</form>
                </div>
            
			</div>
		
		</div>

        <script src="login/js/jquery.min.js"></script>
        <script src="login/js/popper.min.js"></script><!-- Popper for Bootstrap -->
        <script src="login/js/bootstrap.min.js"></script>
        <script src="login/js/jquery.slimscroll.js"></script>
        <script src="login/js/waves.js"></script>
        <script src="login/js/jquery.nicescroll.js"></script>
        <script src="login/js/jquery.scrollTo.min.js"></script>
        <script src="login/js/jquery.app.js"></script>
	
		
	<script>
        function show(v){
           if(v=="booking"){
           
            $("#profile").hide();
            $("#booking").show();
           }
           else{
            $("#profile").show();
            $("#booking").hide();
           }
        }
        function gotoHome(){
            window.location.href="/efuelwebsite";
        }
        </script>

<script>
 
 let toastBox = document.getElementById('toastBox');
 let successMsg='Feedback sent !!';

 function showToast(){
  let toast = document.createElement('div');
  toast.classList.add('toast');
  toast.innerHTML='success';
  toastBox.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 6000);
 }
 
 </script>
    </body>
</html>