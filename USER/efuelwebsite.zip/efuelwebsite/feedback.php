<?php
include("header.php");

require("connection.php");
if(!isset($_COOKIE['userid']))
{
  header("location: login.php?redirecturl=booking.php?id=".$_GET['id']);
}

$response="";
if(isset($_POST['submitbtn']))
{
 
  $name=$_POST['name'];
  $profession=$_POST['profession'];
  $msg=$_POST['message'];
 
  $quote="insert into ef_feedbackmaster (fm_name,fm_profession,fm_message) values ('$name','$profession','$msg')";
  
  $result=mysqli_query($conn,$quote);
  
  if($result==1)
  {
    $response = "Your feedback is submitted.";
  }
  else{
    $response = "Something went wrong, Please try again later .";
  }
}
?>

<style>
  .rf {
    background: 
color-mix(in srgb, var(--default-color), transparent 97%);
    padding: 30px;
    height: 100%;
}



</style>



  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(images/email.jpg);">
      <div class="container position-relative">
        <h1>Reviews</h1>
        <p>Esse dolorum voluptatum ullam est sint nemo et est ipsa porro placeat quibusdam quia assumenda numquam molestias.</p>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Reviews</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    

    <!-- Get A Quote Section -->
    <section id="get-a-quote" class="get-a-quote section">

      <div class="container">

        <div class="row g-0" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-5 quote-bg" style="background-image: url(assets/img/quote-bg.jpg);"></div>

          <div class="col-lg-7" data-aos="fade-up" data-aos-delay="200">
            <form action="" method="post" class="rf">
             
              <div class="row gy-4">

                

                <div class="col-lg-12">
                  <h4>Your Personal Details</h4>
                </div>

                <div class="col-12">
                  <label>Name <span class="text-danger">*</span></label>
                  <input type="text" name="name" class="form-control" placeholder="Name" required="">
                </div>

                <div class="col-12 ">
                  <label>Profession</label>
                  <input type="text" class="form-control" name="profession" placeholder="Profession">
                </div>

                <div class="col-12">
                  <label>Message <span class="text-danger">*</span></label>
                  <textarea class="form-control" name="message" rows="6" placeholder="Message" required=""></textarea>
                </div>

                <div class="col-12 text-center">
                 <!-- <div class="loading">Loading</div>
                  <div class="error-message"></div>-->
                 <!-- <div class="sent-message">Thank you for your valuable feedback..!</div>-->
                  <p><?php echo $response; ?></p>
                  
                  <button class="btn btn-primary" onclick="showToast(successMsg)" name="submitbtn" >Submit</button>
                  <div id="toastBox"></div>
                
                    
                      
                  <!--<button class="btn btn-primary" type="submit" name="submitbtn">Submit</button>-->
                </div>

              </div>
            </form>
          </div><!-- End Quote Form -->

        </div>

      </div>

    </section><!-- /Get A Quote Section -->

  </main>
  <script>
 
 let toastBox = document.getElementById('toastBox');
 let successMsg='Feedback sent !!';

 function showToast(){
  let toast = document.createElement('div');
  toast.classList.add('toast');
  toast.innerHTML='success';
  toastBox.appendChild(toast);
 }
 
 </script>

  

  <?php
include("footer.php");
  ?>