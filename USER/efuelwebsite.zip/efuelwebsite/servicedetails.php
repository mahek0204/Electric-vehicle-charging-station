<?php

include("header.php");
require("connection.php");
?>



  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(assets/img/page-title-bg.jpg);">
      <div class="container position-relative">
        <h1>Service Details</h1>
        <p></p>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Service Details</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <div class="row p-3" style="margin:auto;">
    <div class="col-md-6 p-2 card shadow" style="margin:auto;">
   
<html>
  <body>
<div id="pdf">
        <div class="card-header" >
          <center>
            <h3 class="text-danger">TERMS OF SERVICE</h3>
          </center>
        </div>
        <div class="card-body">
            <div class="row">

            
            </div>
            <div class="row mt-3">
            <!-- <b><h3 class="text-danger">Terms Of Service:</h6></b> -->
            <ul>
                <li> This terms apply to all  users booking a cahtrhing slot thorough our platform.
                <li>Booking a slot does not guarantee immediate charging availability due to potential delays or technical issues.
                  <li>Users must provide accurate details while booking.
                    <li>Slots must be booked in advance through website.
                      <li>Each booking is valid only for the reserved time slot and location.
                        <li>User have to bring the only vihicle who's number is bookes.
                          <li>User must bring the copy of the confimation ticket.
                        <li>Users must ensure their vehicle is compatible with the charging station before booking.
                          <li>The Company reserves rights to cancel bookings due to unforeseen circumstances.
                            <li>In case of company-initiated cancellations, users may be offered an alternative slot or a refund if appplicable.
                              <li>The company des not guarantee continuous availability of slot and charging slot.  
                                <li>Slot booking is only for reserving a time slot and does not guarantee immediate access if prior users exceed their time.
                                  <li>The company is not responsible for the power outlages,technical failures, or othr external disruptions.
                                    <li>Users must arrive on time and vacatnt charging station after their session ends.
                                      <li>Misue of the booking system may result in  restructions or bans.
                                        <li>The Company reserves all rights os suspend or modify the booking system at any time.                      

</ul>
</div>
<div class="row mt-3">
  <b><h5>For support or inquiry:</h5></b>
  <br><br>
  <b><p>Customer Care: +91 9102040812</b><br>
  <b>Email Address: <a href="#">customercare@gmail.com</a></p></b>
</div>

        </div>
        </div>
        <div class="row p-3">
        <!-- <div class="col p-1 card shadow">
        <button class="btn btn-primary" onclick="printDiv('pdf','Title')"><i class="bi bi-download"> &nbsp;Print and Save as pdf</i></button>
        </div>    -->
</div>
        </body>
        </html>
        <a class="btn btn-success" href="/efuelwebsite"><i class="bi bi-house-door-fill">&nbsp;Back to Home</i></a>
    </div>
</div>
</main>  


  </main>

  
  <!-- Scroll Top -->
  <?php
  include("footer.php");
  ?>

</body>

</html>