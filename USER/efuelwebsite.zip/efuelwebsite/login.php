<?php
  
require("connection.php");
$redirect = "";
if(isset($_GET['redirecturl']))
{
    $redirect = $_GET['redirecturl'];
}

if(isset($_POST["submit"]))
{
    
    $uemail = $_POST["useremail"];
    $pwd = $_POST["password"];
    $query="select * from ef_usermaster where um_email = '$uemail' and um_password = '$pwd'";
    
    $result= mysqli_query($conn,$query);
    $nRows = mysqli_num_rows($result);
    $data = mysqli_fetch_array($result);

    if($nRows==1)
    {
        $userid=$data['um_id'];
        $useremail= $data['um_email'];
        $userpass= $data['um_password'];
        echo $useremail, "-" , $userpass;
        setcookie('username',$useremail,time()+86400*1,'/');
        setcookie('userid',$userid,time()+86400*1,'/');
        if(isset($_GET['redirecturl']))
        {
            header("Location: $redirect");
        }
        else{
            header("Location: index.php");
        }
        
    }
}
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="image/f213.png" />
        <link href="assets/img/f213.png" rel="icon">
		
        <title>E Fuel</title>

		<link rel="stylesheet" href="/Dashboard/css/font-awesome.min.css" />

        <link href="login/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="login/css/style.css" rel="stylesheet" type="text/css" />
		
    </head>

<body class="fixed-left" style="background-image:url('assets/img/world-dotted-map.png')">

		<div class="row">
		<div class="col-md-7">
       <div style="text-align:center;margin-top:50px;">
       <img src="assets/img/login_bg.svg" class="img-fluid mb-3 mb-lg-0 mt-auto" alt="" style="height:700px;">
      
       </div>
        </div>
			<div class="col-md-5" style="background:white;height:100vh;" >
			
				<div class="row" style="margin-top:120px;">
				
					<div class="" style="">
                    <center>
						<img src="images/logo.png" class="img-responsive img-fluid login-logo" style="height:200px;width:400px;">
					</center>
                    
                    <!--<form action="forms/login.php" method="post" class="php-email-form" data-aos="fade-up" data-aos-delay="200" form role="form">-->
                    <form role="form" class="row" style="margin-left:200px;" method="post">

						    <div style="">
                            <div class="form-group col-md-8">
                                <label for="exampleInputEmail1">Email I'd</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="useremail" placeholder="Enter your Email">       
                                </div>

                                

                           <div class="form-group col-md-8">
                           <label for="exampleInputPassword1">Password</label>
                            <div class="input-group">
                            
                                <input type="password" id="password" class="form-control" name="password" placeholder="Enter Password">
                                <span class="input-group-addon" onclick="passwordToggle();"><i id="eye" class="fa fa-eye"></i></span>
                                </div>
</div>
							<br><br>

                            <p class="text-danger">
                                <?php
                                if(isset($nRows))
                                {
                                    if($nRows==0)
                                        {
                                            echo "Invalid credentials !!";
                                        }
                                }
                            
                                ?>
						
						    <div class="form-group col-md-8">
                            <!-- <a href="dbindex.php" class="btn btn-logo btn-block btn-lg">Login</a> -->
                            <button name="submit" class="btn btn-logo btn-block btn-lg">Login</button>
                        <p>If you have not register <a href="registration.php">Sign up</a></p>
                            </div>
                            </div>	
						
					</form>
                    </div>
                </div>
			
			</div>
		
            
		</div>

<!-- jQuery -->
		
<script src="login/js/jquery.min.js"></script>
        <script src="login/js/popper.min.js"></script><!-- Popper for Bootstrap -->
        <script src="login/js/bootstrap.min.js"></script>
        <script src="login/js/jquery.slimscroll.js"></script>
        <script src="login/js/waves.js"></script>
        <script src="login/js/jquery.nicescroll.js"></script>
        <script src="login/js/jquery.scrollTo.min.js"></script>
        <script src="login/js/jquery.app.js"></script>
	
		<script>
            function passwordToggle(){
                var type = $("#password").attr("type");
                if(type=="password"){
                    $("#eye").attr("class","fa fa-eye-slash");
                    $("#password").attr("type","text");
                }
                else{
                    $("#eye").attr("class","fa fa-eye");
                    $("#password").attr("type","password");
                }
            }
        </script>
	
    </body>
</html>