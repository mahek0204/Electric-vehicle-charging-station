<?php
include("header.php");
require "connection.php";
?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(assets/img/page-title-bg.jpg);">
      <div class="container position-relative">
        <h1>Services</h1>
        <p>Welcome to E fuel, where we offer top-quality solutions tailored to your needs. Our goal is to provide exceptional services, ensuring efficiency, relaibility, and customer satisfaction.</p>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Services</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- Featured Services Section -->
    <section id="featured-services" class="featured-services section">

      <div class="container">

        <div class="row gy-4">

        <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="icon flex-shrink-0"><i class="bi bi-pin-map"></i></div>
            <div>
              <h4 class="title">Charging Station Locator:</h4>
              <p class="description">Interactive maps showing nearby charging stations.Filters for connector types, charging speeds, and availablity.</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="100">
            <div class="icon flex-shrink-0"><i class="bi bi-calendar-event"></i></div>
            <div>
              <h4 class="title">Service Scheduling:</h4>
              <p class="description">Allowing customers to schedule maintenance appointments online.</p>
            </div>
          </div>
          
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="300">
            <div class="icon flex-shrink-0"><i class='fas fa-toggle-on'></i></div>
            <div>
              <h4 class="title">Real-time Availability & Satus:</h4>
              <p class="description">Live updates on wheather a station is available, in use or out of service.</p>
            </div>

</div>
</div>

<div class="container">

        <div class="row gy-4">

            <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="icon flex-shrink-0"><i class="bi bi-currency-rupee"></i></div>
            <div>
              <h4 class="title">Pricing:</h4>
              <p class="description">Display of charging costs.</p>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="100">
            <div class="icon flex-shrink-0"><i class="bi bi-book"></i></div>
            <div>
              <h4 class="title">Reservation System:</h4>
              <p class="description">Option to book a charging slot in advance. Time limits and cancellation policy.</p>
            </div>
          </div>
          
          <div class="col-lg-4 col-md-6 service-item d-flex" data-aos="fade-up" data-aos-delay="300">
            <div class="icon flex-shrink-0"><i class="bi bi-clock-history"></i></div>
            <div>
              <h4 class="title">User Account & History:</h4>
              <p class="description">User profiles for managing charging preferences. Charging history and usage reports.</p>
            </div>

            
        
           
          </div><!-- End Service Item -->

        </div>

      </div>

    </section><!-- /Featured Services Section -->

    <!-- Services Section -->
    <section id="services" class="services section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <span>Our Services<br></span>
        <h2>Our Services</h2>
        <p> Find, book, and manage EV charging stations effortlessly with real-time availability, secure payments, and smart navigation.</p>       
        
      </div><!-- End Section Title -->

      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/location.jpeg" alt="" style="width:100%;" class="img-fluid">
              </div>
              <h3>Charging Station Locator</h3>
              <p>Interactive maps showing nearby charging stations. Filters for connector types, charging speeds, and availablity.</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/schedule.svg" alt="" style="width:100%;" class="img-fluid">
              </div>
              <h3>Service Scheduling</h3>
             <p>Allowing customers to schedule maintenance appointments online</p> 
                   </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/status.jpeg" alt="" style="width:100%;" class="img-fluid">
              </div>
              <h3>Real-time Availability & Satus</h3>
              <p>Live updates on wheather a station is available, in use or out of service.</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="400">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/pricing.jpeg" alt="" class="img-fluid">
              </div>
              <h3>Pricing</h3>
              <p>Display of charging costs.</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="500">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/booking.jpeg" alt="" class="img-fluid">
              </div>
              <h3>Reservation System</h3>
              <p>Option to book a charging slot in advance. Time limits and cancellation policy.</p>
            </div>
          </div><!-- End Card Item -->

          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="600">
            <div class="card">
              <div class="card-img">
                <img src="assets/img/history.png" alt="" class="img-fluid">
              </div>
              <h3>User Accounts & History</h3>
              <p>User profiles for managing charging preferences. Charging history and usage reports.</p>
            </div>
          </div><!-- End Card Item -->

        </div>

      </div>

    </section><!-- /Services Section -->

    <!-- Features Section -->
    

    <!-- Testimonials Section -->
    

    <!-- Faq Section -->
    

  </main>

  <?php
include("footer.php");
  ?>

  
</body>

</html>