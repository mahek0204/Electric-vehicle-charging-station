<?php
include("header.php");
require "connection.php";

$book="SELECT bm_id from ef_bookingmaster";
$bookresult=mysqli_query($conn,$book);
$bdata=mysqli_num_rows($bookresult);

$count="SELECT pm_pumpname from ef_pumpmaster";
$result=mysqli_query($conn,$count);
$data=mysqli_num_rows($result);

$tbQuery1 = "SELECT * FROM ef_feedbackmaster WHERE fm_status='1'";
$tbResult1 = mysqli_query($conn,$tbQuery1);
$totalCompleted = mysqli_num_rows($tbResult1);

$totalfeed = "SELECT fm_status FROM ef_feedbackmaster ";
$totalre = mysqli_query($conn,$totalfeed);
$totaldata = mysqli_num_rows($totalre);

?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(images/feedback.png);">
      <div class="container position-relative">
        <h1>About</h1>
        <p>Driving and maintaining your electric vehicle is a breeze. With no gears, spark plugs and fuel tanks, electric vehicles truly redefine convenience. What's more? electric vehicles are as simple to charge as your mobile phone.</p>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">About</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- About Section -->
    <section id="about" class="about section">

      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-5 position-relative align-self-start order-lg-last order-first" data-aos="fade-up" data-aos-delay="200">
            <img src="images/about1.jpg" class="img-fluid" alt="">
          <!--  <a href="https://www.youtube.com/watch?v=Y7f98aduVJ8" class="glightbox pulsating-play-btn"></a>-->
          </div>

          <div class="col-lg-6 content order-last  order-lg-first" data-aos="fade-up" data-aos-delay="100">
            <h3>About Us</h3>
            <p>
            At our E Fuel pump, we are passionate about powering the future of transportation. Founded with a vision to accelerate the adoption of electric vehicles, we specialize in innovative charging solutions designed to meet the needs of both urban and rural communities.
            </p>
            <ul>
              <li>
                <i class="bi bi-menu-button-wide-fill"></i>
                <div>
                  <h5>Easy Online Booking</h5>
                  <p>Reserve your charging slot effortlessly through our user-friendly platform.</p>
                </div>
              </li>
              <li>
                <i class="bi bi-geo-alt"></i>
                <div>
                  <h5>Convenience First</h5>
                  <p>Our platform offers a user-friendly interface that allows you to find, book, and manage charging sessions in real time.</p>
                </div>
              </li>
              <li>
                <i class="bi bi-chat-square-heart"></i>
                <div>
                  <h5>Customer-Centric Approach</h5>
                  <p>We prioritize your experience, ensuring reliable and accessible charging options.</p>
                </div>
              </li>
            </ul>
          </div>

        </div>

      </div>

    </section><!-- /About Section -->

    <!-- Stats Section -->
    <section id="stats" class="stats section">
    <!--<div class="page-title dark-background" data-aos="fade" style="background-image: url(images/total.png);">-->

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-4">

          <div class="col-lg-3 col-md-6">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="<?php echo $bdata ?>" data-purecounter-duration="1" class="purecounter"></span>
              <p>Registrations</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="<?php echo $data ?>" data-purecounter-duration="1" class="purecounter"></span>
              <p>Pumps</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="<?php echo $totalCompleted ?>" data-purecounter-duration="1" class="purecounter"></span>
              <p>Happy Clients</p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6">
            <div class="stats-item text-center w-100 h-100">
              <span data-purecounter-start="0" data-purecounter-end="<?php echo $totaldata ?>" data-purecounter-duration="1" class="purecounter"></span>
              <p>Reviews</p>
            </div>
          </div><!-- End Stats Item -->
</div>
        </div>

      </div>

    </section><!-- /Stats Section -->
<br>
<br>
<br>
<br>
<br>
  </main>
<br>
<br>
<br>
<br>
  <?php
include("footer.php");
  ?>