<?php
include("header.php");
require("connection.php");
?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(assets/img/page-title-bg.jpg);">
      <div class="container position-relative">
        <h1>Privacy Page</h1>
        <p></p>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Privacy Page</li>
          </ol>
        </nav> 
      </div>
    </div><!-- End Page Title -->

    <!-- Starter Section Section -->
    <section id="starter-section" class="starter-section section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <span>What is privacy policy ?<br></span>
        <h2>What is privacy policy ? </h2>
        <p>E Fuel <b>"we," "our," or "us"</b> is commited to protecting your privacy. This privacy Ploicy explains how we collect, 
      use, disclose, and safeguard your information when you visit our website
    and use our services related to booking slots for electric vehicle charging 
  stations.</p>
  
      </div><!-- End Section Title -->
      <div class="container" data-aos="fade-up">
      <div>
    <ol><h4><b>
      <li>INFORMATION WE COLLECT</li>
      </ol></h4></b>
    
  <ol type=a><b><h5>
      <li>Personal information:</li>
      </ol></b></h5> 
    
    <ul>
      <li>Name</li>
      <li>Email address</li>
      <li>Vehicle details</li>
    </ul>
    
    <ol type=a start=b><b><h5>
    <li>Non-personal Information</li>
    </ol></b></h5>

    <ul>
      <li>IP address</li>
      <li>Browser type and version</li>
      <li>Device information</li>
      <li>Usage data (e.g., pages visited, booking history)</li>
    </ul>

  </ol></b></h5>

<ol type=1 start=2><h4><b>
<li>How We Use Your Information</li>

</ol></h4></b>

<ul>
  We use the collected information for the following purposes:
    <br><br>

<ul>
<li>To process and manage your EV charging slot bookings</li>

<li>To communicate with you regarding your reservations and service updates</li>

<li>To improve our website and services</li>

<li>To ensure security and prevent fraudulent activities</li>

<li>To comply with legal obligations</li>
</ul>
  </ul>
<ol type=1 start=3><h4><b>
<li>Sharing Your Information</li>

</ol></h4></b> 

<ul>We do not sell your personal information. However, we may share your information with:

<ul>
<li>Service providers who assist in payment processing and booking management</li>

<li>Law enforcement or government agencies when required by law</li>

<li>Business partners for service improvements (with your consent)</li>
</ul>
</ul>

<ol type=1 start=4><h4><b>
<li>Data Security</li>
</ol></h4></b> 

<ul>We implement security measures to protect your data from unauthorized access, alteration, disclosure, or destruction. However, no internet-based service is completely secure, so we cannot guarantee absolute security.</ul>

<ol type=1 start=5><h4><b>
<li>Cookies and Tracking Technologies</li>
</ol></h4></b> 

<ul>We use cookies and similar tracking technologies to enhance user experience, analyze website traffic, and personalize content. You can manage your cookie preferences through your browser settings.</ul>

<ol type=1 start=6><h4><b>
<li>Third-Party Links</li>
</ol></h4></b> 

<ul>Our website may contain links to third-party websites. We are not responsible for the privacy practices of these external sites. Please review their policies before providing any personal information.</ul>

<ol type=1 start=7><h4><b>
<li>Your Rights</li>
</ol></h4></b> 


<ul>You have the right to:
  <ul>

<li>Access, update, or delete your personal data

<li>Opt-out of marketing communications

<li>Request data portability

<li>Withdraw consent for data processing (where applicable)

<li>To exercise these rights, contact us at [Your Contact Email].
</ul>
</ul>

<ol type=1 start=8><h4><b>
<li>Changes to This Policy</li>
</ol></h4></b> 

<ul>We may update this Privacy Policy periodically. Any changes will be posted on this page with an updated effective date.</ul>

<ol type=1 start=9><h4><b>
<li>Contact Us</li>
</ol></h4></b> 


<ul>If you have any questions or concerns about this Privacy Policy, please contact us at: <br>
<br>
<b>E Fuel </b><br><br>
Email: <a href="">customercare@gmail.com</a> <br>
Phone: 9102040812 
</ul>

    
  </div>

      
        
      </div>
      
    </section><!-- /Starter Section Section -->

  </main>

 <?php
 include("footer.php");
 ?>

</body>

</html>