<?php
include "header.php";
require("connection.php");
$id = $_GET['id'];
$query="select * from ef_bookingmaster
inner join ef_pumpmaster on ef_bookingmaster.pm_id=ef_pumpmaster.pmId
where bm_id=$id";
$result=mysqli_query($conn,$query);
$getData=mysqli_fetch_array($result);

?>
<main class="main">
<div class="page-title dark-background" data-aos="fade" style="background-image: url(assets/img/page-title-bg.jpg);">
      <div class="container position-relative">
        <h1><i class="bi bi-check-circle"></i></h1>
        <p> You has successfully finished the process of reserving a slot or service through the efuel platform.</p>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Booked</li>
          </ol>
        </nav>
      </div>
    </div>
<div class="row p-3" style="margin:auto;">
    <div class="col-md-6 p-2 card shadow" style="margin:auto;">
   
<html>
  <body>
<div id="pdf">
        <div class="card-header" >
          <center>
            <h3 class="text-success">YOUR SLOT HAS BEEN BOOKED SUCCESSFULLY</h3>
</center>
        </div>
        <div class="card-body">
            <div class="row">

            <div class="col-md-6">
                <b><h5 class="text-dark">Pumpname:</b> &nbsp;<?php echo $getData['pm_pumpname'] ?></h5>
                </div>
                <div class="col-md-6">
                <b><h5 class="text-dark">Date: </b> &nbsp; <?php echo $getData['bm_date'] ?></h5>
                </div>
                <div class="col-md-6">
                <b><h5 class="text-dark">Time: </b> &nbsp; <?php echo $getData['bm_time'] ?></h5>
                </div>
                <div class="col-md-6">
                <b><h5 class="text-dark">Vehicle No: </b> &nbsp; <?php echo $getData['bm_vehicleNo'] ?></h5>
                </div>
                <div class="col-md-12">
               <b> <h5 class="text-dark">Total Price: </b> &nbsp; <?php echo $getData['bm_totalPrice'] ?></h5>
                </div>
            </div>
            <div class="row mt-3">
            <b><h6 class="text-danger">Note :</h6></b>
            <ul>
                <li> We do not endorse or warrant the existence, conduct, performance, safety, quality, compatibility of the Vehicle with the Charging Station and shall not be responsible for any incident of fire, electric shock, personal injury, disruption of Services or any other hazard that may be caused to the User or the Vehicle on account of availing the Services at the Charging Station.
                
            </ul>
</div>
        </div>
        </div>
        <div class="row p-3">
        <div class="col p-1 card shadow">
        <button class="btn btn-primary" onclick="printDiv('pdf','Title')"><i class="bi bi-download"> &nbsp;Print and Save as pdf</i></button>
        </div>   
</div>
        </body>
        </html>
        <a class="btn btn-success" href="/efuelwebsite"><i class="bi bi-house-door-fill">&nbsp;Back to Home</i></a>
    </div>
</div>
</main>
<?php
include "footer.php";
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script>
  var doc = new jsPDF();

function saveDiv(divid, Title) {
doc.fromHTML(`<html><head><title>${Title}</title></head><body>` + document.getElementById(divId).innerHTML + '</body></html>');
doc.save('sucess_booking.pdf');
}

function printDiv(divId,
 title) {

 let mywindow = window.open('', 'PRINT', 'height=650,width=900,top=100,left=150');

 mywindow.document.write(`<html><head><title>${title}</title>`);
 mywindow.document.write('</head><body >');
 mywindow.document.write(document.getElementById(divId).innerHTML);
 mywindow.document.write('</body></html>');

 mywindow.document.close(); // necessary for IE >= 10
 mywindow.focus(); // necessary for IE >= 10*/

 mywindow.print();
 mywindow.close();

 return true;
}
</script>