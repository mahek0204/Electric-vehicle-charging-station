<?php
if(!isset($_COOKIE['userid']))
{
  header("location: login.php?redirecturl=booking.php?id=".$_GET['id']);
}
require("connection.php");
$id=$_GET['id'];
$availableSlot;
$defaultPrice;
$defaultTotalPrice=0;
$dateError;
$level;
$time;
$today = date('Y-m-d');
$timeError="";

if(isset($_POST['btnCB']))
{
  //echo "dsdsdsd"; exit;
  
  $bdate = $_POST['b_Date'];
  $levelId=$_POST['b_LevelId'];
  $time = $_POST['b_Time'];
  $vehicleNo=$_POST['b_vNo'];
  $percentage = $_POST['b_Percentage'];
  $dPrice = $_POST['b_dprice'];
  $totalPrice = $_POST['b_price'];
  $pumpId = $id;
  $userid = $_COOKIE['userid'];
  $status="Booked";
  $Query= "insert into ef_bookingmaster (um_id,pm_id,lm_id,bm_date,bm_time,bm_percent,bm_price,bm_totalPrice,bm_vehicleNo,bm_status) values ($userid,$pumpId,$levelId,'$bdate','$time',$percentage,$dPrice,$totalPrice,'$vehicleNo','$status')";
  $Result= mysqli_query($conn,$Query);
  $lastId = mysqli_insert_id($conn);
  
  
//    $count="SELECT COUNT(bm_id) as total FROM ef_bookingmaster WHERE bm_status='Completed' and um_id=$userid";
//    $countrecords= mysqli_query($conn,$count);
//    $row = mysqli_fetch_assoc($countrecords);
//    $checkQuery = "SELECT COUNT(cm_creditpoint) as points_given FROM ef_creditmaster WHERE um_id = $userid";
// $checkResult = mysqli_query($conn, $checkQuery);
// $rewardRow = mysqli_fetch_assoc($checkResult);
  
//    echo $row['total']; exit;
//    $fdata=mysqli_fetch_array($result);
//     if($row['total'] >= 3 && $row['total']%4 == 0)
//     {
//       $cquery="INSERT INTO ef_creditmaster(um_id,bm_id,cm_creditpoint) values ($userid,$lastId,30)"; 
//       $result2=mysqli_query($conn,$cquery);
//         //
//     }

$bookingQuery = "SELECT COUNT(bm_id) as total_completed FROM ef_bookingmaster WHERE um_id = $userid AND bm_status = 'Completed'";
$bookingResult = mysqli_query($conn, $bookingQuery);
$bookingRow = mysqli_fetch_assoc($bookingResult);

$totalCompleted = $bookingRow['total_completed'];

// Check if the user has already received a reward for this cycle
 $rewardCheckQuery = "SELECT COUNT(cm_creditpoint) as reward_count FROM ef_creditmaster WHERE um_id = $userid AND cm_creditpoint = 30";
 $rewardCheckResult = mysqli_query($conn, $rewardCheckQuery);
 $rewardRow = mysqli_fetch_assoc($rewardCheckResult);

$rewardCount = $rewardRow['reward_count'];

// Award points only for every 4th completed booking (4, 8, 12, ...)
if ($totalCompleted % 4 == 0 && $rewardCount < ($totalCompleted / 4)) {
    // Insert credit points
    $creditQuery = "INSERT INTO ef_creditmaster (um_id, bm_id, cm_creditpoint) VALUES ($userid, $lastId, 30)";
    mysqli_query($conn, $creditQuery);
} 

  $url = "/efuelwebsite/success.php?id=$lastId";
  header("location: $url");
  
}

if(isset($_POST["submit"]))
{

  $date=$_POST['date'];
  $currentDate =  date('Y-m-d');
 
  if($date != "")
{
  
  $level=$_POST['level'];
  $time=$_POST['time'];

  if($date==$currentDate)
  {
    date_default_timezone_set('Asia/Kolkata');
  $givenDT = date('Y-m-d').' '.$time;
  $cd = new DateTime();
  $gd = new DateTime($givenDT);
  if($gd>=$cd)
  {
    $interval = $cd->diff($gd);

  if($interval->i >= 30)
  {
    $bookingQuery = "SELECT * FROM ef_bookingmaster WHERE bm_date='$date' && lm_id=$level && bm_time='$time' && (bm_status='Booked' || bm_status='Running')";
  $bookingResult = mysqli_query($conn,$bookingQuery);
  $totalBooking = mysqli_num_rows($bookingResult);

  $totalQuery = "SELECT * FROM ef_pointmaster where pm_id=$id && lm_id=$level";
  $totalResult = mysqli_query($conn,$totalQuery);
  $pointData = mysqli_fetch_array($totalResult);
  $totalSlot=0;
  if(mysqli_num_rows($totalResult)>=1)
  {
    $data= mysqli_fetch_array($totalResult);
    $totalSlot = $pointData['pt_available'];
    $defaultPrice=$pointData['pt_price'];
    $defaultTotalPrice = 1*$defaultPrice;
  }

 $availableSlot = $totalSlot-$totalBooking;
  }
  else{
    $timeError="Time Error";
  }
  }
  else{
    $timeError="Time Error";
  }
  
  
  }
  else{
    $bookingQuery = "SELECT * FROM ef_bookingmaster WHERE bm_date='$date' && lm_id=$level && bm_time='$time' && (bm_status='Booked' || bm_status='Running')";
  $bookingResult = mysqli_query($conn,$bookingQuery);
  $totalBooking = mysqli_num_rows($bookingResult);

  $totalQuery = "SELECT * FROM ef_pointmaster where pm_id=$id && lm_id=$level";
  $totalResult = mysqli_query($conn,$totalQuery);
  $pointData = mysqli_fetch_array($totalResult);
  $totalSlot=0;
  if(mysqli_num_rows($totalResult)>=1)
  {
    $data= mysqli_fetch_array($totalResult);
    $totalSlot = $pointData['pt_available'];
    $defaultPrice=$pointData['pt_price'];
    $defaultTotalPrice = 1*$defaultPrice;
  }

 $availableSlot = $totalSlot-$totalBooking;
  }
  $timeError;
  
}
else{
$dateError="Please select date";
}
}

 $query= "SELECT * from ef_pointmaster
 inner join ef_levelmaster on ef_pointmaster.lm_id=ef_levelmaster.lm_id 
 where pm_id=$id";
//echo "sdsd"; exit;
//   if(isset($_POST['btnCB'])){
//     echo "select um_id,bm_id from ef_bookingmaster where bm_status='Completed' and um_id=".$userid.""; exit;
//     $query="select um_id,bm_id from ef_bookingmaster where bm_status='Completed' and um_id=".$userid."";
//     $result=mysqli_query($conn,$query);
//     if(mysqli_num_rows($query)==3);
// {
//      $query="INSERT into ef_creditmaster (cm_creditpoint) values 30";
//       $result=mysqli_query($conn,$query);
//     }
//   }

 $result = mysqli_query($conn,$query);
include("header.php");
?>
  

    <!-- Page Title -->
    <div class="page-title dark-background" data-aos="fade" style="background-image: url(assets/img/page-title-bg.jpg);">
      <div class="container position-relative">
        <h1>Booking</h1>
        <p>Driving and maintaining your electric vehicle is a breeze. With no gears, spark plugs and fuel tanks, electric vehicles truly redefine convenience. What's more? electric vehicles are as simple to charge as your mobile phone.</p>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">About</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- About Section -->
    <section id="about" class="about section">

     <div class="container">
        <div class="row">
            <div class="col-md-10">
            <div class="form">
									
                                    <form role="form" class="row" method="post">
                                                            
                                            <div class="col-md-3 form-group">
                                                <label for="exampleInputEmail1">Date <span class="text-danger">*</span></label>
                                                <input type="date" min="<?php echo $today; ?>" value="<?php isset($date)? print $date:""; ?>" name="date" id="bdate" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                                <span class="text-danger"><?php isset($dateError) ? print $dateError:""; ?></span>
                                            </div>

                                            <div class="col-md-3 form-group">
                                            <label for="exampleInputEmail1">Level <span class="text-danger">*</span></label>
                                            <!-- <input type="text" name="lmid" value="<?php echo $getData['lm_id']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"> -->
            
                                            <select name="level" id="blevel" class="form-control">
												<?php
												while($l = mysqli_fetch_array($result))
												{
													?>
													<option value="<?php echo $l['lm_id']; ?>" <?php isset($level)? $level==$l['lm_id'] ? print "selected" :"" :"";?>><?php echo $l['lm_name']; ?></option>
													<?php
												}
												?>
											</select>
                                        
                                        
                                        </div>
                    
                                            <div class="col-md-3 form-group">
                                                <label for="exampleInputEmail1">Time <span class="text-danger">*</span></label>
                                               <select class="form-control" id="btime" name="time">
                                                <option value="12:00 AM" <?php isset($time)? $time=="12:00 AM" ? print "selected" :"" :"";?>>12:00 AM</option>
                                                <option value="1:00 AM" <?php isset($time)? $time=="1:00 AM" ? print "selected" :"" :"";?>>1:00 AM</option>
                                                <option value="2:00 AM" <?php isset($time)? $time=="2:00 AM" ? print "selected" :"" :"";?>>2:00 AM</option>
                                                <option value="3:00 AM" <?php isset($time)? $time=="3:00 AM" ? print "selected" :"" :"";?>>3:00 AM</option>
                                                <option value="4:00 AM" <?php isset($time)? $time=="4:00 AM" ? print "selected" :"" :"";?>>4:00 AM</option>
                                                <option value="5:00 AM" <?php isset($time)? $time=="5:00 AM" ? print "selected" :"" :"";?>>5:00 AM</option>
                                                <option value="6:00 AM" <?php isset($time)? $time=="6:00 AM" ? print "selected" :"" :"";?>>6:00 AM</option>
                                                <option value="7:00 AM" <?php isset($time)? $time=="7:00 AM" ? print "selected" :"" :"";?>>7:00 AM</option>
                                                <option value="8:00 AM" <?php isset($time)? $time=="8:00 AM" ? print "selected" :"" :"";?>>8:00 AM</option>
                                                <option value="9:00 AM" <?php isset($time)? $time=="9:00 AM" ? print "selected" :"" :"";?>>9:00 AM</option>
                                                <option value="10:00 AM" <?php isset($time)? $time=="10:00 AM" ? print "selected" :"" :"";?>>10:00 AM</option>
                                                <option value="11:00 AM" <?php isset($time)? $time=="11:00 AM" ? print "selected" :"" :"";?>>11:00 AM</option>
                                                <option value="12:00 PM" <?php isset($time)? $time=="12:00 PM" ? print "selected" :"" :"";?>>12:00 PM</option>
                                                <option value="1:00 PM" <?php isset($time)? $time=="1:00 PM" ? print "selected" :"" :"";?>>1:00 PM</option>
                                                <option value="2:00 PM" <?php isset($time)? $time=="2:00 PM" ? print "selected" :"" :"";?>>2:00 PM</option>
                                                <option value="3:00 PM" <?php isset($time)? $time=="3:00 PM" ? print "selected" :"" :"";?>>3:00 PM</option>
                                                <option value="4:00 PM" <?php isset($time)? $time=="4:00 PM" ? print "selected" :"" :"";?>>4:00 PM</option>
                                                <option value="5:00 PM" <?php isset($time)? $time=="5:00 PM" ? print "selected" :"" :"";?>>5:00 PM</option>
                                                <option value="6:00 PM" <?php isset($time)? $time=="6:00 PM" ? print "selected" :"" :"";?>>6:00 PM</option>
                                                <option value="7:00 PM" <?php isset($time)? $time=="7:00 PM" ? print "selected" :"" :"";?>>7:00 PM</option>
                                                <option value="8:00 PM" <?php isset($time)? $time=="8:00 PM" ? print "selected" :"" :"";?>>8:00 PM</option>
                                                <option value="9:00 PM" <?php isset($time)? $time=="9:00 PM" ? print "selected" :"" :"";?>>9:00 PM</option>
                                                <option value="10:00 PM" <?php isset($time)? $time=="10:00 PM" ? print "selected" :"" :"";?>>10:00 PM</option>
                                                <option value="11:00 PM" <?php isset($time)? $time=="11:00 PM" ? print "selected" :"" :"";?>>11:00 PM</option>
                                                
                                               </select>
                                            </div>
                    
                                          <div class="col-md-3 form-group">
                                              <button type="submit" name="submit" class="btn btn-warning btn-lg mt-3">Check</button>
                                          </div>
                    
                                        <div class="col-md-12">
                                         <p class="text-danger fw-bold">
                                          <?php
                                         if(isset($availableSlot))
                                         {
                                            echo $availableSlot." slots are available.";
                                         }
                                          ?>
                                         </p>
                                        </div>
                                       </div>
                                
                                
                                  </div>


                               </div>
                               
                              <?php
                              if(isset($availableSlot))
                              {
                                if($availableSlot>=1)
                                {
                                  ?>
                                  <div class="row">
                               <div class="col-md-3 form-group">
                                        <label for="exampleInputEmail1">Vehicle No <span class="text-danger">*</span></label>
                                        <input type="text" name="vehicleno" class="form-control" id="bvNo" aria-describedby="emailHelp">
                                </div>

                                <div class="col-md-3 form-group">
                                                <label for="exampleInputEmail1">
                                                  Select Percentage <span class="text-danger">*</span>
                                                  <?php
                                                  if(isset($defaultPrice))
                                                  {
                                                    echo "<small class='text-danger'>(Rs. $defaultPrice for 10%)</small>";
                                                  }
                                                  ?>
                                                </label>
                                                <select id="per" class="form-control" onchange="setPrice();" name="percent">
                                                <option value="1">10</option>
                                                <option value="2">20</option>
                                                <option value="3">30</option>
                                                <option value="4">40</option>
                                                <option value="5">50</option>
                                                <option value="6">60</option>
                                                <option value="7">70</option>
                                                <option value="8">80</option>
                                                <option value="9">90</option>
                                                </select>
                      
                                  </div>
                                  <div class="col-md-3 form-group">
                        <label>Total Price <span class="text-danger">*</span></label>
                        <input type="text" value="<?php echo $defaultTotalPrice; ?>" readonly id="totalPrice" class="form-control">
                      </div>
                      <div class="col-md-3 form-group">
                                              <button type="button" id="confirm" name="submit"  class="btn btn-warning btn-lg mt-3">Confirm</button>
                                          </div>
                                          <div class="col-md-12">
                                            <p id="dError" style="display:none" class=" p-3 text-danger">Please fill all the mendatory fields.</p>
                                          </div>
                                  <?php
                                }
                              }
                              ?>

                                         
    </section><!-- /About Section -->

   
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Booking Confirmation</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <div class="row">
        <form method="post" >
        <div class="form-group col-md-6">
          <label>Date</label>
          <input type="text" class="form-control" name="b_Date" id="b_Date" readonly>
        </div>
        <div class="form-group col-md-6">
          <label>Level</label>
          <input type="text" class="form-control" name="b_Level" id="b_Level" readonly>
          <input type="hidden" class="form-control" name="b_LevelId" id="b_LevelId" readonly>
        </div>
        <div class="form-group col-md-6">
          <label>Time</label>
          <input type="text" class="form-control" name="b_Time" id="b_Time" readonly>
        </div>
        <div class="form-group col-md-6">
          <label>Vehicle No.</label>
          <input type="text" class="form-control" name="b_vNo" id="b_vNo" readonly>
        </div>
        <div class="form-group col-md-6">
          <label>Percentage</label>
          <input type="text" class="form-control" name="b_Percentage" id="b_Percentage" readonly>
         
        </div>
        <div class="form-group col-md-6">
          <label>Total Price</label>
          <input type="text" class="form-control" name="b_price" id="b_price" readonly>
          <input type="hidden" class="form-control" name="b_dprice" id="b_dprice" readonly>
        </div>
        <div class="form-group float-end mt-3">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" name="btnCB" class="btn btn-primary">Confirm Booking</button>
      </div>
        </form>
       </div>

      </div>
     
    </div>
  </div>
</div>
 
   
<br>
<br>
  </main>

<?php
include("footer.php");
?>
<script>

  function setPrice(){
    var value =$("#per").val();
    var defaultPrice = <?php echo  $defaultPrice ?>;
    var totalPrice = defaultPrice*value;
    $("#totalPrice").val(totalPrice);
  }

  $("#confirm").click(function(){
    var vNo = $("#bvNo").val();
    if(vNo.length==0)
  {
    $("#dError").show();
  }
  else{
    $("#dError").hide();
    $("#b_Date").val($("#bdate").val());
    $("#b_Level").val($("#blevel option:selected").text());
    $("#b_LevelId").val($("#blevel option:selected").val());
    $("#b_Time").val($("#btime").val());
    $("#b_vNo").val($("#bvNo").val());
    $("#b_Percentage").val($("#per option:selected").text());
    $("#b_price").val($("#totalPrice").val());
    $("#b_dprice").val("<?php echo $defaultPrice ?>");

   // $("#exampleModal").modal("show");
  }
  $("#exampleModal").modal("show");
   // 
  });
</script>