
<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
	header("Location: index.php");
}
$query="SELECT * FROM ef_levelmaster";
$result=mysqli_query($conn,$query);
$pageHeading="Levels";
include "../layout/dbheader.php";

?>
				<div class="row">
                    <div class="col-md-12">
                        <div class="card" style="margin-bottom:100px;">
                            <div class="header style=" style="display:flex;">
                                <h4 class="title" style="width:90%">Levels</h4>
                               <!-- <p class="category">Here is a subtitle for this table</p>-->
								 <a href="create.php" class="btn btn-warning f-r" name="create"><i class="fa fa-plus"></i>&nbsp; Create</a> 
                            </div>
                            <div class="content table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
											<th class="text-center">Name</th>
											<th class="text-center">Capacity</th>
										<!--	<th class="text-center">Description</th>-->
											<th class="text-center">Vehicle Type</th>
											<th class="text-center">Status</th>
											<th class="text-center">Action</th>
										</tr>
									</thead>
                                    <tbody class="text-center">
										<?php
										while($d=mysqli_fetch_array($result))
										{
											?>
                                        <tr>
                                        	<td><?php echo $d['lm_name']; ?></td>
                                        	<td><?php echo $d['lm_capacity']; ?></td>
                                        	<!--<td> /*echo $d['lm_description'];*/</td>-->
											<td> <?php echo $d['lm_vehicleType'];  ?> </td>
                                        	<td>
												<?php
												if($d['lm_status']==1)
												{
													echo "<span class='label label-success'>Active</span>";
												}
												else
												{
													echo "<span class='label label-danger'>De-Active</span>";
												}
												?>
												</td>
												<td> 
	
												<div class="btn-group">
												  <a href="edit.php?id=<?php echo $d['lm_id']; ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i></a>
												  <!--<a href="#" class="btn btn-warning btn-sm"><i class="fa fa-book"></i></a>-->
												  <a href="delete.php?id=<?php echo $d['lm_id']; ?>" onclick="return confirm('Are you sure you want to delete ?');" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
												</div> 
												</td>
                                        </tr>
									<?php
										}
									?>
											
                                        	
											
                                      
                                        
                                    </tbody>
									
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
						
						
					</div>
				</div>


<?php
include "../layout/dbfooter.php";
?>