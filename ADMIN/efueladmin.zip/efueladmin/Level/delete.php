<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
    header("Location: index.php");
}
$deleteId = $_GET['id'];
$query="DELETE FROM ef_levelmaster WHERE lm_id=$deleteId";
$result=mysqli_query($conn,$query);
header("location: index.php");
?>