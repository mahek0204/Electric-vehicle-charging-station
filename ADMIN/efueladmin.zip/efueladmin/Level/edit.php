<?php
require('../connection.php');
if(!isset($_COOKIE['adminname']))
{
    header("location: ../dblogin.php");
}

$id=$_GET['id'];
$query="SELECT * FROM ef_levelmaster WHERE lm_id=$id";
$result = mysqli_query($conn,$query);
$getData = mysqli_fetch_array($result);

$types = explode(",",$getData['lm_vehicleType']);

if(isset(($_POST['submit'])))
{
    $type = implode(",",$_POST['vehicleType']);
    $name=$_POST['name'];
    $capacity=$_POST['capacity'];
    $desc=$_POST['desc'];
    $status=0;
    if(isset($_POST['status']))
    {
        $status=1;
    }

    $query1="UPDATE ef_levelmaster SET lm_name='$name',lm_capacity='$capacity',lm_description='$desc',
    lm_status=$status, lm_vehicleType='$type' where lm_id=$id";
    $result1=mysqli_query($conn,$query1);
    if($result1==1)
    {
        header("location: index.php");
    }
    else
    {
        $errorMessage="Oops!!Something went wrong..";
    }
}
$pageHeading="Levels";
include("../layout/dbheader.php");
?>

<div class="content">
					<div class="container-fluid">
					
						<div class="row" style="margin: 10px 0;">
						
							<div class="col-md-12">
							
								<div class="card" style="margin-bottom:100px;">
								
									<div class="header">
										<h4 class="title">Update Level</h4>
										<!--<p class="category">Here is a subtitle for this table</p><br>-->
										
									</div>
									
									<div class="form">
									
										<form role="form" class="row" method="post">
										
                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Name</label>
                                            <input type="text" name="name" value="<?php echo $getData['lm_name']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputPassword1">Capacity</label>
                                            <input type="text" name="capacity" value="<?php echo $getData['lm_capacity']; ?>"class="form-control" id="exampleInputPassword1">
                                        </div>
										
										<div class="col-md-12 form-group">
                                            <label for="exampleInputEmail1">Description</label>
											<textarea rows="4" input type="text" name="desc" class="form-control t-area"><?php echo $getData['lm_description']; ?></textarea>
                                            
                                        </div>

                                        <div class="col-md-12 form-group">
                                            <label for="exampleInputEmail1">Vehicle Type</label>
                                            <input type="checkbox" value="2 Wheeler" class="" name="vehicleType[]" <?php in_array("2 Wheeler",$types)==true? print "checked" : print ""; ?> id="exampleInputEmail1" aria-describedby="emailHelp" <?php echo $getData['lm_vehicleType']; ?>> 2 Wheeler &nbsp;
											<input type="checkbox" value="3 Wheeler" class="" name="vehicleType[]" <?php in_array("3 Wheeler",$types)==true? print "checked" : print ""; ?> id="exampleInputEmail1" aria-describedby="emailHelp" <?php echo $getData['lm_vehicleType']; ?>>  3 Wheeler &nbsp;
											<input type="checkbox" value="4 Wheeler" class="" name="vehicleType[]" <?php in_array("4 Wheeler",$types)==true? print "checked" : print ""; ?> id="exampleInputEmail1" aria-describedby="emailHelp" <?php echo $getData['lm_vehicleType']; ?>>  4 Wheeler &nbsp;
                                        </div>
										
										<!--<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Type</label>
                                            <select class="form-control">
												<option>Select User Type</option>
												<option>Candidate</option>
												<option>Instructor</option>
												<option>Demo</option>
											</select>
                                        </div>-->
										
										<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Status</label>
                                            <input type="checkbox" name=status value="1" class="" id="exampleInputEmail1" aria-describedby="emailHelp" <?php $getData['lm_status']==1 ? print 'checked' : '' ; ?>>
                                            
                                        </div>
										
										<div class="col-md-12 text-danger">
											<h6>
												<?php
												if(isset($errorMessage))
												{
													echo $errorMessage;
												}
												?>
											</h6>
										</div>
                                           <!-- <label for="exampleInputEmail1">Action</label>
                                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >-->
                                            
                                        
										
										
										<div class="col-md-12 form-group">
											<button type="submit" name="submit" class="btn btn-warning btn-lg">Update</button>
										</div>
										
                                    </form>
									</div>
								
								</div>
							
							</div>
							
						</div>
						
						
					</div>
				</div>
<?php
include "../layout/dbfooter.php";
?>