<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
	header("location: ../dbindex.php");
}

$errorMessage;
if(isset($_POST['submit']))
{
	$type = implode(",",$_POST['vehicleType']);
	$name=$_POST['Name'];
	$capacity=$_POST['Capacity'];
	$desc=$_POST['Description'];
	$status=0;
	if(isset($_POST['status']))
	{
		$status=1;
	}

	$query="INSERT INTO ef_levelmaster (lm_name,lm_description,lm_status,lm_capacity,lm_vehicleType) VALUES ('$name','$desc',$status,'$capacity','$type')";
	$result=mysqli_query($conn,$query);
	if($result==1)
	{
		header("Location: index.php");
	}
	else
	{
		$errorMessage="Oops!! Something went wrong..!";
	}
}

$page='Level';
$pageHeading="Levels";
include "../layout/dbheader.php";
?>


				<div class="content">
					<div class="container-fluid">
					
						<div class="row" style="margin: 10px 0;">
						
							<div class="col-md-12">
							
								<div class="card" style="margin-bottom:100px;">
								
									<div class="header">
										<h4 class="title">Create Level</h4>
										<!--<p class="category">Here is a subtitle for this table</p><br>-->
										
									</div>
									
									<div class="form">
									
										<form role="form" class="row" method="post">
										
                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Name</label>
                                            <input type="text" name="Name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                            
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputPassword1">Capacity</label>
                                            <input type="text" name="Capacity" class="form-control" id="exampleInputPassword1">
                                        </div>
										
										<div class="col-md-12 form-group">
                                            <label for="exampleInputEmail1">Description</label>
											<textarea rows="4" name="Description" class="form-control t-area"></textarea>
                                            
                                        </div>

										<div class="col-md-6 form-group">
                                            <label for="exampleInputPassword1">Vehicle Type</label>
                                            <input type="text" name="vehicleType" class="form-control" id="exampleInputPassword1">
                                        </div>
										
										<!--<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Type</label>
                                            <select class="form-control">
												<option>Select User Type</option>
												<option>Candidate</option>
												<option>Instructor</option>
												<option>Demo</option>
											</select>
                                        </div>-->
										<div class="col-md-12 form-group">
                                            <label for="exampleInputEmail1">Vehicle Type</label>
                                            <input type="checkbox" value="2 Wheeler" class="" name="vehicleType[]"  id="exampleInputEmail1" aria-describedby="emailHelp">  2 Wheeler &nbsp;
											<input type="checkbox" value="3 Wheeler" class="" name="vehicleType[]"  id="exampleInputEmail1" aria-describedby="emailHelp">  3 Wheeler &nbsp;
											<input type="checkbox" value="4 Wheeler" class="" name="vehicleType[]"  id="exampleInputEmail1" aria-describedby="emailHelp">  4 Wheeler &nbsp;
                                        </div>
										
										<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Status</label>
                                            <input type="checkbox" value="1" class="" name="Status" checked id="exampleInputEmail1" aria-describedby="emailHelp">
                                            
                                        </div>
										
										<div class="col-md-12 text-danger">
											<h6>
												<?php
												if(isset($errorMessage))
												{
													echo $errorMessage;
												}
												?>
											</h6>
										</div>
                                           <!-- <label for="exampleInputEmail1">Action</label>
                                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >-->
                                            
										
										<div class="col-md-12 form-group">
											<button type="submit" name="submit" class="btn btn-warning btn-lg">Submit</button>
										</div>
										
                                    </form>
									</div>
								
								</div>
							
							</div>
							
						</div>
						
						
					</div>
				</div>
<?php
include "../layout/dbfooter.php";
?>





