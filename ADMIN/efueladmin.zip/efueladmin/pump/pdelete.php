<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
    header("Location: ../dblogin.php");
}
$deleteId = $_GET['id'];
$query="DELETE FROM ef_pumpmaster WHERE pmId=$deleteId";
$result=mysqli_query($conn,$query);
header("location: ../pump/pindex.php");
?>