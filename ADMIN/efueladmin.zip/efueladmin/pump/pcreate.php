<?php
require('../connection.php');
if(!isset($_COOKIE['adminname']))
{
	header("location: dbindex.php");
}

$errorMessage;
if(isset($_POST['submit']))
{
	$p_name=$_POST['pumpname'];
	$email=$_POST['email'];
	$longitude=$_POST['long'];
    $latitude=$_POST['lat'];
	$desc=$_POST['description'];
	$cont=$_POST['contactNo'];
	$pwd=$_POST['password'];
	//$image=$_POST['image'];
	$filename = $_FILES["file"]["name"];
    $tempname = $_FILES["file"]["tmp_name"];
	$folder = "./logo" . $filename;
	$status=0;
	if(isset($_POST['status']))
	{
		$status=1;
	}
	
	$query="INSERT INTO ef_pumpmaster (pm_pumpname,pm_email,pm_password,pm_lat,pm_long,pm_image,pm_description,pm_contactNo,pm_status) VALUES ('$p_name','$email','$pwd',$latitude,$longitude,'$filename','$desc',$cont,$status)";
	$result=mysqli_query($conn,$query);
	if (move_uploaded_file($tempname, $folder)) 
	{
		echo "<h3>&nbsp; Image uploaded successfully!</h3>";
	} else {
		echo "<h3>&nbsp; Failed to upload image!</h3>";
	}
	if($result==1)
	{
		header("Location: pindex.php");
	}
	else
	{
		$errorMessage="Oops!! Something went wrong..!";
	}
}
$pageHeading="Pump";
include "../layout/dbheader.php";
?>


				<div class="content">
					<div class="container-fluid">
					
						<div class="row" style="margin: 10px 0;">
						
							<div class="col-md-12">
							
								<div class="card" style="margin-bottom:100px;">
								
									<div class="header">
										<h4 class="title">Create Pump</h4>
										<!--<p class="category">Here is a subtitle for this table</p><br>-->
										
									</div>
									
									<div class="form">
									
										<form role="form" class="row" method="post" enctype="multipart/form-data">
										
                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Pump Name</label>
                                            <input type="text" name="pumpname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                            
                                        </div>
										<div class="col-md-6 form-group">
                                            <label for="logo" id="logo">Logo</label>
                                            <input type="file" name="file" class="form-control" id="logo">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputPassword1">Email</label>
                                            <input type="email" name="email" class="form-control" id="exampleInputPassword1">
                                        </div>

										<div class="col-md-6 form-group">
                                            <label for="exampleInputPassword1">Password</label>
                                            <input type="text" name="password" class="form-control" id="exampleInputPassword1">
                                        </div>

										<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Latitude</label>
											<input type="text" name="lat" class="form-control" id="exampleInputPassword1">
                                            
                                        </div>
										
										<!--<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Type</label>
                                            <select class="form-control">
												<option>Select User Type</option>
												<option>Candidate</option>
												<option>Instructor</option>
												<option>Demo</option>
											</select>
                                        </div>-->
										
										<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Longitude</label>
                                            <input type="text" name="long" class="form-control" checked id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>
										
										<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Description</label>
                                            <input type="text" name="description" class="form-control" checked id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>

										<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Contact No.</label>
                                            <input type="number" name="contactNo" class="form-control" checked id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>


                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Status</label>
                                            <input type="checkbox" value="1" class="" name="status" checked id="exampleInputEmail1" aria-describedby="emailHelp">
                                            
                                        </div>

										<div class="col-md-12 text-danger">
											<h6>
												<?php
												if(isset($errorMessage))
												{
													echo $errorMessage;
												}
												?>
											</h6>
										</div>
                                           <!-- <label for="exampleInputEmail1">Action</label>
                                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >-->
                                            
										
										<div class="col-md-12 form-group">
											<button type="submit" name="submit" class="btn btn-warning btn-lg">Submit</button>
										</div>
										
                                    </form>
									</div>
								
								</div>
							
							</div>
							
						</div>
						
						
					</div>
				</div>
<?php
include "../layout/dbfooter.php";
?>





