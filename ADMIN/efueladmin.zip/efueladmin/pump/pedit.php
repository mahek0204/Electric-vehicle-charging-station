<?php
require('../connection.php');
if(!isset($_COOKIE['adminname']))
{
    header("location: ../dblogin.php");
}

$id=$_GET['id'];
$query="SELECT * FROM ef_pumpmaster WHERE pmId = $id";
$result = mysqli_query($conn,$query);
$getData = mysqli_fetch_array($result);

if(isset(($_POST['submit'])))
{
    $name=$_POST['pumpname'];
    $email=$_POST['email'];
    $longitude=$_POST['long'];
    $latitude=$_POST['lat'];
    $description=$_POST['desc'];
    $contactNo=$_POST['cntc'];
    $pwd=$_POST['password'];
    $folder=$filename;

    if(isset($_FILES['file']['tmp_name']))
{
    $filename = $_FILES["file"]["name"];
    $folder      = addslashes(file_get_contents($_FILES['file']['tmp_name']));
    $image = addslashes($_FILES['file']['name']);
    move_uploaded_file($_FILES["file"]["tmp_name"],"./logo" . $_FILES["file"]["name"]);
    $folder ="./logo" . $_FILES["file"]["name"];
}
    $status=0;
    if(isset($_POST['status']))
    {
        $status=1;
    }

    $query1="UPDATE ef_pumpmaster SET pm_pumpname='$name',pm_image='$filename',pm_email='$email',pm_password='$pwd',pm_long=$longitude,pm_lat=$latitude,pm_description='$description',pm_contactNo=$contactNo,
    pm_status=$status WHERE pmId=$id";
    
    $result1=mysqli_query($conn,$query1);
    if($result1==1)
    {
        header("location: pindex.php");
    }
    else
    {
        $errorMessage="Oops!!Something went wrong..";
    }
}
$pageHeading="Pump";
include("../layout/dbheader.php");
?>

<div class="content">
					<div class="container-fluid">
					
						<div class="row" style="margin: 10px 0;">
						
							<div class="col-md-12">
							
								<div class="card" style="margin-bottom:100px;">
								
									<div class="header">
										<h4 class="title">Update Pump</h4>
										<!--<p class="category">Here is a subtitle for this table</p><br>-->
										
									</div>
									
									<div class="form">
									
										<form role="form" method="post" class="row" enctype="multipart/form-data">
										
                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Pump name</label>
                                            <input type="text" name="pumpname" value="<?php echo $getData['pm_pumpname']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label for="logo">Logo</label>
                                            <input type="file" name="file" value="<?php echo $getData['pm_image']; ?>" class="form-control" id="logo">
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Email</label>
                                            <input type="email" name="email" value="<?php echo $getData['pm_email']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Password</label>
                                            <input type="text" name="password" value="<?php echo $getData['pm_password']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Latitude</label>
                                            <input type="text" name="lat" value="<?php echo $getData['pm_lat']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputPassword1">Longitude</label>
                                            <input type="text" name="long" value="<?php echo $getData['pm_long']; ?>"class="form-control" id="exampleInputPassword1">
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputPassword1">Description</label>
                                            <input type="text" name="desc" value="<?php echo $getData['pm_description']; ?>"class="form-control" id="exampleInputPassword1">
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputPassword1">Contact No.</label>
                                            <input type="text" name="cntc" value="<?php echo $getData['pm_contactNo']; ?>"class="form-control" id="exampleInputPassword1">
                                        </div>

										<!--<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Type</label>
                                            <select class="form-control">
												<option>Select User Type</option>
												<option>Candidate</option>
												<option>Instructor</option>
												<option>Demo</option>
											</select>
                                        </div>-->
										
										<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Status</label>
                                            <input type="checkbox" name=status value="1" class="" id="exampleInputEmail1" aria-describedby="emailHelp" <?php $getData['pm_status']==1 ? print 'checked' : '' ; ?>>
                                            
                                        </div>
										
										<div class="col-md-12 text-danger">
											<h6>
												<?php
												if(isset($errorMessage))
												{
													echo $errorMessage;
												}
												?>
											</h6>
										</div>
                                           <!-- <label for="exampleInputEmail1">Action</label>
                                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >-->
                                            
                                        
										
										
										<div class="col-md-12 form-group">
											<button type="submit" name="submit" class="btn btn-warning btn-lg">Update</button>
										</div>
										
                                    </form>
									</div>
								
								</div>
							
							</div>
							
						</div>
						
						
					</div>
				</div>
<?php
include "../layout/dbfooter.php";
?>