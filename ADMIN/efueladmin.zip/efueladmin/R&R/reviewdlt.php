<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
    header("Location: ../dblogin.php");
}
$deleteId = $_GET['id'];
$query="DELETE FROM ef_feedbackmaster WHERE fm_id=$deleteId";
$result=mysqli_query($conn,$query);
header("location: ../R&R/review.php");
?>