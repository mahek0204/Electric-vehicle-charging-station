<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
	header("Location: index.php");
}

 //$query=" INSERT into ef_creditmaster(um_id,bm_id,cm_creditmaster) select um_id,bm_id,10 from ef_bookingmaster where bm_status='Completed' ";
 
$query1="SELECT * from ef_creditmaster";
$result=mysqli_query($conn,$query1);

$pageHeading="Credit Points";
include "../layout/dbheader.php";

?>		
        		<div class="row">
                    <div class="col-md-12">
                        <div class="card" style="margin-bottom:100px;">
                            <div class="header style=" style="display:flex;">
                                <h4 class="title" style="width:90%">Credit Points</h4>
                               <!-- <p class="category">Here is a subtitle for this table</p>-->
								 
                            </div>
                            <div class="content table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
											<th class="text-center">Booking Id</th>
											<th class="text-center">User Name</th>
                                            <th class="text-center">CreditPoints</th>
										</tr>
									</thead>
                                    <tbody class="text-center">
										<?php
										while($d=mysqli_fetch_array($result))
										{
											?>
                                        <tr>
                                        	<td><?php echo $d['bm_id']; ?></td>
                                        	<td><?php echo $d['um_id']; ?> </td>
                                            <td><?php echo $d['cm_creditpoint']; ?> </td>
                                            <?php
                                            }
                                            ?>
                                              						
										</td>
                                        </tr>	                                        
                                    </tbody>
									
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
						
						
					</div>
				</div>


<?php
include "../layout/dbfooter.php";
?>