<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
	header("Location: index.php");
}

$pumpQuery = "SELECT * FROM ef_pumpmaster";
$pumpResult = mysqli_query($conn,$pumpQuery);

$levelQuery = "SELECT * FROM ef_levelmaster";
$levelResult = mysqli_query($conn,$levelQuery);

$fdate="";
$tdate="";
$level="";
$pump="";
$status="All";
$totalPrice=0;
if(isset($_POST['btnSave']))
{
	$rId = $_POST['recordId'];
	$status=$_POST['newStatus'];
	
	$updateQuery = "UPDATE ef_bookingmaster SET bm_status='$status' WHERE bm_id=$rId";
	
	$updateResult = mysqli_query($conn,$updateQuery);
}

if(isset($_POST['btnSearch']))
{
	$fdate = $_POST['fdate'];
	$tdate = $_POST['tdate'];
	$level = $_POST['level'];
	$pump = $_POST['pump'];
	$status=$_POST['status'];
	if($_COOKIE['admintype']=="ADM")
{
	$query="SELECT * FROM ef_bookingmaster
	inner join ef_usermaster on ef_bookingmaster.um_id=ef_usermaster.um_id
	inner join ef_pumpmaster on ef_bookingmaster.pm_id=ef_pumpmaster.pmId
	inner join ef_levelmaster on ef_bookingmaster.lm_id=ef_levelmaster.lm_id
	where ef_bookingmaster.bm_date>='$fdate' 
	and ef_bookingmaster.bm_date<='$tdate' 
	and ef_bookingmaster.lm_id=$level 
	and ef_bookingmaster.pm_id=$pump
	and ef_bookingmaster.bm_status='$status'";
	$result=mysqli_query($conn,$query);
}
else{
	$pId = $_COOKIE['adminid'];
	$query="SELECT * FROM ef_bookingmaster
inner join ef_usermaster on ef_bookingmaster.um_id=ef_usermaster.um_id
inner join ef_pumpmaster on ef_bookingmaster.pm_id=ef_pumpmaster.pmId
inner join ef_levelmaster on ef_bookingmaster.lm_id=ef_levelmaster.lm_id
where ef_bookingmaster.pm_id=$pId 
and (ef_bookingmaster.bm_date>='$fdate'
and ef_bookingmaster.bm_date<='$tdate') 
and ef_bookingmaster.lm_id=$level
and ef_bookingmaster.pm_id=$pump
and ef_bookingmaster.bm_status='$status'";
$result=mysqli_query($conn,$query);
}
}
else{
	if($_COOKIE['admintype']=="ADM")
	{
		$query="SELECT * FROM ef_bookingmaster
		inner join ef_usermaster on ef_bookingmaster.um_id=ef_usermaster.um_id
		inner join ef_pumpmaster on ef_bookingmaster.pm_id=ef_pumpmaster.pmId
		inner join ef_levelmaster on ef_bookingmaster.lm_id=ef_levelmaster.lm_id";
		$result=mysqli_query($conn,$query);
	}
	else{
		$pId = $_COOKIE['adminid'];
		$query="SELECT * FROM ef_bookingmaster
	inner join ef_usermaster on ef_bookingmaster.um_id=ef_usermaster.um_id
	inner join ef_pumpmaster on ef_bookingmaster.pm_id=ef_pumpmaster.pmId
	inner join ef_levelmaster on ef_bookingmaster.lm_id=ef_levelmaster.lm_id
	where ef_bookingmaster.pm_id=$pId";
	$result=mysqli_query($conn,$query);
	}
}



$pageHeading="Report";
include "../layout/dbheader.php";
?>
<div class="container">
<div class="row p-2">
	<form method="post">
		<div class="row">
			<div class="col-md-2 form-group">
				<label>From Date</label>
				<input type="date" required name="fdate" value="<?php echo $fdate ?>" class="form-control">
			</div>
			<div class="col-md-2 form-group">
				<label>To Date</label>
				<input type="date" required value="<?php echo $tdate ?>" name="tdate" class="form-control">
			</div>

			<div class="col-md-2 form-group">
                                            <label for="exampleInputEmail1">Pump</label>
                                            <!-- <input type="text" name="pump" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"> -->
                                            <select name="pump" class="form-control">
												<?php
												while($p = mysqli_fetch_array($pumpResult))
												{
													?>
													<option value="<?php echo $p['pmId']; ?>"><?php echo $p['pm_pumpname']; ?></option>
													<?php
												}
												?>
											</select>
                                        </div>

			<div class="col-md-2 form-group">
                        <label for="exampleInputPassword1">Level</label>
                                <!-- <input type="text" name="level" class="form-control" id="exampleInputPassword1">-->
								<select name="level" required class="form-control">
										<?php
											while($l = mysqli_fetch_array($levelResult))
											{
											?>
											<option value="<?php echo $l['lm_id']; ?>"><?php echo $l['lm_name']; ?></option>
											<?php
											}
											?>
										</select>
			</div>
			<div class="col-md-2 form-group">
                        <label for="exampleInputPassword1">Status</label>
                                <!-- <input type="text" name="level" class="form-control" id="exampleInputPassword1">-->
							
								<select name="status" required class="form-control">
										<option value="All">All</option>
										<option value="Booked" <?php $status=="Booked"? print "selected":"" ?>>Booked</option>
										<option value="Completed" <?php $status=="Completed"? print "selected":"" ?> >Completed</option>
										<option value="Cancel" <?php $status=="Cancel"? print "selected":"" ?> >Cancel</option>
										<option value="Running" <?php $status=="Running"? print "selected":"" ?> >Running</option>
										<option value="Reject" <?php $status=="Reject"? print "selected":"" ?> >Reject</option>
										</select>
			</div>
            
			
			<div class="col-md-2 form-group">
				
				<button type="submit" name="btnSearch" style="margin-top:25px;" class="btn btn-sm btn-primary"><i class="fa fa-search"></i> Search</button>
				<button class="btn btn-sm btn-success" style="margin-top:25px;margin-right:20px" type="button" id="export"><i class="fa fa-file-excel-o"></i> Export</button>
			</div>
		</div>
	</form>
</div>
</div>
<div class="row">
                    <div class="col-md-12">
                        <div class="card" style="margin-bottom:100px;">
                            <div class="header style=" style="display:flex;">
                                <h4 class="title" style="width:90%">Report</h4>
                               <!-- <p class="category">Here is a subtitle for this table</p>-->
								 
                            </div>
                            <div class="content table-responsive">
                                <table id="tblReport" class="table table-striped">
									<form method="post">
                                    <thead>
                                        <tr>
											
											<th class="text-center"> User</th>
											<th class="text-center">Pump</th>
											<th class="text-center">Level Id</th>
											<th class="text-center">Date</th>
											<th class="text-center">Time</th>
                                            <th class="text-center">Percentage</th>
                                            <th class="text-center">Price</th>
                                            <th class="text-center">Total price</th>
                                            <th class="text-center">Vehicle No.</th>
                                            <th class="text-center">Status</th>
											
										</tr>
									</thead>
                                    <tbody class="text-center">
										<?php
										while($d=mysqli_fetch_array($result))
										{
											$totalPrice += $d['bm_totalPrice'];
											?>
                                        <tr>
                                        	
                                        	<td><?php echo $d['um_name']; ?></td>
                                            <td> <?php echo $d['pm_pumpname'];  ?> </td>
                                        	<td><?php echo $d['lm_name']; ?></td>
											<td> <?php echo $d['bm_date'];  ?> </td>
                                            <td> <?php echo $d['bm_time'];  ?> </td>
                                            <td> <?php echo $d['bm_percent'];  ?> </td>
                                            <td> <?php echo $d['bm_price'];  ?> </td>
                                            <td> <?php echo $d['bm_totalPrice'];  ?> </td>
                                            <td> <?php echo $d['bm_vehicleNo'];  ?> </td>
											<td> 
											<?php echo $d['bm_status'];  ?>
											</td>
												
                                        </tr>
									<?php
										}
									?>
									<tr>
										<th colspan="7" class="text-right">Total Amount</th>
										<th class="text-center"><?php echo $totalPrice; ?></th>
										<th colspan="2"></th>
									</tr>
                                    </tbody>
									</form>
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
						
						
					</div>
				</div>


<script src="/efueladmin/js/jquery.min.js"></script>
<script>
	function updateRecord(id){
		$("#status_"+id).hide();
		$("#updateStatus_"+id).show();
		$("#btnEdit_"+id).hide();
		$("#btnSave_"+id).show();
	}
	</script>

<?php
include "../layout/dbfooter.php";
?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.1/xlsx.full.min.js"></script>
<script>
    $('#export').click(function() {
        var wb = XLSX.utils.table_to_book(document.getElementById('tblReport'), {sheet:"Sheet1"});
        XLSX.writeFile(wb, "report.xlsx");
    });
</script>