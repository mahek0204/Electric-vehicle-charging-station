
<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
	header("Location: index.php");
}

$query="SELECT * FROM ef_contactmaster";
$result=mysqli_query($conn,$query);
$pageHeading="Contact inquiry";
include "../layout/dbheader.php";
				?>			

				<div class="row">
                    <div class="col-md-12">
                        <div class="card" style="margin-bottom:100px;">
                            <div class="header style=" style="display:flex;">
                                <h4 class="title" style="width:90%">Contact Inquiry</h4>
                               <!-- <p class="category">Here is a subtitle for this table</p>-->
								<!-- <a href="create.php" class="btn btn-warning f-r"><i class="fa fa-plus"></i>&nbsp; Create</a>--> 
                            </div>
                            <div class="content table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
											<th class="text-center">Name</th>
											<th class="text-center">Email</th>
											<th class="text-center">Subject</th>
											<th class="text-center">Message</th>
											<th class="text-center">Contact No</th>
											<th class="text-center">Date</th>
                                            <th class="text-center">Action</th>
										</tr>
									</thead>
                                    <tbody class="text-center">
										<?php
										while($d=mysqli_fetch_array($result))
										{
											?>
                                        <tr>
                                        	<td><?php echo $d['cm_name']; ?></td>
                                        	<td><?php echo $d['cm_email']; ?></td>
                                        	<td><?php echo $d['cm_subject']; ?></td>
											<td> <?php echo $d['cm_message'];  ?> </td>
                                            <td> <?php echo $d['cm_contactNo'];  ?> </td>
                                        	<td> <?php echo $d['cm_currentDt'];  ?><td> 
	
												<div class="btn-group">
												  
												  <a href="delete.php?id=<?php echo $d['cm_id']; ?>" onclick="return confirm('Are you sure you want to delete ?');" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
												</div> 
												</td>
                                        </tr>
									<?php
										}
									?>
											
                                        	
											
                                        
                                    </tbody>
									
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
						
						
					</div>
				</div>


<?php
include "../layout/dbfooter.php";
?>