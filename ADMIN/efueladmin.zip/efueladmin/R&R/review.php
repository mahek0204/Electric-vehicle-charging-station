<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
	header("Location: index.php");
}


$pageHeading="Reviews";

if(isset($_POST['submit']))
{
    $id=$_POST['id'];
    $status=$_POST['status'];
    if($status==0)
    {
        $query="UPDATE ef_feedbackmaster SET fm_status=1 WHERE fm_id=$id";
        $update = mysqli_query($conn,$query);
    }
    else
	{
		$query="UPDATE ef_feedbackmaster SET fm_status=0 WHERE fm_id=$id";
        $update = mysqli_query($conn,$query);
    }
	
}
    
$query="SELECT * FROM ef_feedbackmaster";
$result=mysqli_query($conn,$query);

include "../layout/dbheader.php";
?>						
				<div class="row">
                    <div class="col-md-12">
                        <div class="card" style="margin-bottom:100px;">
                            <div class="header style=" style="display:flex;">
                                <h4 class="title" style="width:90%">Reviews</h4>
                               <!-- <p class="category">Here is a subtitle for this table</p>-->
								
                            </div>
                            <div class="content table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
											<th class="text-center">Name</th>
											<th class="text-center">Profession</th>
											<th class="text-center">Message</th>
											<th class="text-center">Status</th>
                                            <th class="text-center">Action</th>
										</tr>
									</thead>
                                    <tbody class="text-center">
										<?php
										while($d=mysqli_fetch_array($result))
										{
											?>
                                        <tr>
                                        	<td><?php echo $d['fm_name']; ?></td>
                                        	<td><?php echo $d['fm_profession']; ?></td>
                                        	<td><?php echo $d['fm_message']; ?></td>
                                        	<td> <?php echo $d['fm_status'];  ?><td> 

                                            <div class="btn-group">
												<form method="post">
                                                    <input type="hidden" name="id" value="<?php echo $d['fm_id']; ?>">
                                                    <input type="hidden" name="status" value="<?php echo $d['fm_status']; ?>">
												  <button type="submit" name="submit" class="btn btn-info btn-sm"><i class="fa fa-edit"></i></button>
                                                  <a href="reviewdlt.php?id=<?php echo $d['fm_id']; ?>" onclick="return confirm('Are you sure you want to delete ?');" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                                </form>
                                                </div> 
												</td>
                                        </tr>
									<?php
										}
									?>
                                        
                                    </tbody>
									
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
						
						
					</div>
				</div>


<?php
include "../layout/dbfooter.php";
?>