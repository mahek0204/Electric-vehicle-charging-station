<?php
  
require("connection.php");
if(isset($_POST["submit"]))
{
    $uname = $_POST["username"];
    $pwd = $_POST["password"];

    $query="select * from ef_adminmaster where adm_username = '$uname' and adm_password = '$pwd'";
    
    $result= mysqli_query($conn,$query);
    $nRows = mysqli_num_rows($result);
    $data = mysqli_fetch_array($result);

    if($nRows==1)
    {
        $username= $data['adm_username'];
        $userid= $data['adm_id'];
        echo $userid, "-" , $username;
        setcookie('adminname',$username,time()+86400*1,'/');
        setcookie('adminid',$userid,time()+86400*1,'/');
        setcookie('admintype',"ADM",time()+86400*1,'/');
        header("Location: dbindex.php");
    }
    }
    
    

?>




<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="image/f213.png" />
		
        <title>E Fuel</title>

		<link rel="stylesheet" href="/efueladmin/css/font-awesome.min.css" />

        <link href="/efueladmin/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="/efueladmin/css/style.css" rel="stylesheet" type="text/css" />
		
    </head>


    <body class="fixed-left">

		<div class="row">
		
			<div class="col-md-12" >
			
				<div class="card-box lgn">
				
					<center>
						<img src="image\logo.png" class="img-responsive login-logo">
					</center>
					
					<form role="form" method="post">
                                        
						<div class="form-group">
                            <label for="exampleInputEmail1">Username</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="username" placeholder="Enter Username">       
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Password</label>
                            <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Enter Password">
                        </div>

                        

							
						<!-- <div>
							<a href="#">Forgot Password ?</a>
						</div><br><br> -->

                        <p class="text-danger">
                            <?php
                            if(isset($nRows))
                            {
                                if($nRows==0)
                                {
                                    echo "Invalid credentials !!";
                                }
                            }
                            
                            ?>
						
						<div class="form-group">
                        <!-- <a href="dbindex.php" class="btn btn-logo btn-block btn-lg">Login</a> -->
                         <button name="submit" class="btn btn-logo btn-block btn-lg">Login</button>
                        
                        </div>	
						
					</form>
				
				</div>
			
			</div>
		
		</div>
        
        <!-- jQuery -->
		
        <script src="/efueladmin/js/jquery.min.js"></script>
        <script src="/efueladmin/js/popper.min.js"></script><!-- Popper for Bootstrap -->
        <script src="/efueladmin/js/bootstrap.min.js"></script>
        <script src="/efueladmin/js/jquery.slimscroll.js"></script>
        <script src="/efueladmin/js/waves.js"></script>
        <script src="/efueladmin/js/jquery.nicescroll.js"></script>
        <script src="/efueladmin/js/jquery.scrollTo.min.js"></script>
        <script src="/efueladmin/js/jquery.app.js"></script>
	
		
	
    </body>
</html>