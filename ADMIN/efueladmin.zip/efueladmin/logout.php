<?php
setcookie("adminid","",time() -0,"/");
setcookie("adminname","",time() -0,"/");
header("location: dblogin.php");
?>