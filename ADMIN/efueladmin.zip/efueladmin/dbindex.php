<?php
require("./connection.php");
if(!isset($_COOKIE['adminname']))
{
header("location: dblogin.php");
}

$today = date('Y-m-d');

if(isset($_POST['btnSave']))
{
	$rId = $_POST['recordId'];
	$status=$_POST['newStatus'];
	$updateQuery = "UPDATE ef_bookingmaster SET bm_status='$status' WHERE bm_id=$rId";
	$updateResult = mysqli_query($conn,$updateQuery);
}

if($_COOKIE['admintype']=="ADM")
{
	$query="SELECT * FROM ef_bookingmaster
	inner join ef_usermaster on ef_bookingmaster.um_id=ef_usermaster.um_id
	inner join ef_pumpmaster on ef_bookingmaster.pm_id=ef_pumpmaster.pmId WHERE ef_bookingmaster.bm_date='$today' AND (ef_bookingmaster.bm_status='Booked' OR ef_bookingmaster.bm_status='Running')";
	$result=mysqli_query($conn,$query);
}
else{
	$pId = $_COOKIE['adminid'];
	$query="SELECT * FROM ef_bookingmaster
inner join ef_usermaster on ef_bookingmaster.um_id=ef_usermaster.um_id
inner join ef_pumpmaster on ef_bookingmaster.pm_id=ef_pumpmaster.pmId
where ef_bookingmaster.pm_id=$pId AND ef_bookingmaster.bm_date='$today' AND (ef_bookingmaster.bm_status='Booked' OR ef_bookingmaster.bm_status='Running')";
$result=mysqli_query($conn,$query);
}

//today booking

$ttQuery="SELECT * FROM ef_bookingmaster where bm_date='$today'";
$ttResult = mysqli_query($conn,$ttQuery);
$todayBooking = mysqli_num_rows($ttResult);

//total booking
$totalBooking=0;
$tbQuery = "SELECT * FROM ef_bookingmaster";
$tbResult = mysqli_query($conn,$tbQuery);
$totalBooking = mysqli_num_rows($tbResult);

$tbQuery1 = "SELECT * FROM ef_bookingmaster WHERE bm_status='completed'";
$tbResult1 = mysqli_query($conn,$tbQuery1);
$totalCompleted = mysqli_num_rows($tbResult1);

$tbQuery2 = "SELECT SUM(bm_totalPrice) as totalRevenue FROM ef_bookingmaster WHERE bm_status='completed'";
$tbResult2 = mysqli_query($conn,$tbQuery2);
$totalRevenue = mysqli_fetch_array($tbResult2);

$pageHeading="Dashboard";
include "./layout/dbheader.php";
?>
				<!--<div class="content">
					<div class="container-fluid">-->
						<div class="row">
							<div class="col-lg-3 col-sm-6">
								<div class="card">
									<div class="content">
										<div class="row">
											<div class="col-xs-5">
												<div class="icon-big icon-warning text-center">
													<i class="fa fa-list-alt"></i>
												</div>
											</div>
											<div class="col-xs-7">
												<div class="numbers">
													<p>Today Booking</p>
													<?php echo $todayBooking; ?>
												</div>
											</div>
										</div>
										<div class="footer">
											<hr>
											<div class="stats">
												<i class="ti-reload"></i> Updated now
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-sm-6">
								<div class="card">
									<div class="content">
										<div class="row">
											<div class="col-xs-5">
												<div class="icon-big icon-success text-center">
													<i class="fa fa-list"></i>
												</div>
											</div>
											<div class="col-xs-7">
												<div class="numbers">
													<p>Total Booking</p>
													<?php echo $totalBooking; ?>
												</div>
											</div>
										</div>
										<div class="footer">
											<hr>
											<div class="stats">
												<i class="ti-calendar"></i> Last day
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-sm-6">
								<div class="card">
									<div class="content">
										<div class="row">
											<div class="col-xs-5">
												<div class="icon-big icon-danger text-center">
													<i class="fa fa-list"></i>
												</div>
											</div>
											<div class="col-xs-7">
												<div class="numbers">
													<p>Total Completed</p>
													<?php echo $totalCompleted; ?>
												</div>
											</div>
										</div>
										<div class="footer">
											<hr>
											<div class="stats">
												<i class="ti-timer"></i> In the last hour
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-sm-6">
								<div class="card">
									<div class="content">
										<div class="row">
											<div class="col-xs-5">
												<div class="icon-big icon-info text-center">
													<i class="fa fa-rupee"></i>
												</div>
											</div>
											<div class="col-xs-7">
												<div class="numbers">
													<p>Total Revenue</p>
													<?php echo $totalRevenue[0]; ?>
												</div>
											</div>
										</div>
										<div class="footer">
											<hr>
											<div class="stats">
												<i class="ti-reload"></i> Updated now
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						
						
						<div class="row">
                    <div class="col-md-12">
                        <div class="card" style="margin-bottom:100px;">
                            <div class="header style=" style="display:flex;">
                                <h4 class="title" style="width:90%">Today's Booking</h4>
                               
								<!-- <a href="createuser.html" class="btn btn-warning f-r"><i class="fa fa-plus"></i>&nbsp; Create</a> -->
                            </div>
                            <div class="content table-responsive">
                                <table class="table table-striped">
								<thead>
                                        <tr>
											<th class="text-center">Booking Id</th>
											<th class="text-center">User</th>
											<th class="text-center">Pump</th>
											<th class="text-center">Level Id</th>
											<th class="text-center">Date</th>
											<th class="text-center">Time</th>
                                            <th class="text-center">Percentage</th>
                                            <th class="text-center">Price</th>
                                            <th class="text-center">Total price</th>
                                            <th class="text-center">Vehicle No.</th>
                                            <th class="text-center">Status</th>
											<th class="text-center">Action</th>
										</tr>
									</thead>
                                    <tbody class="text-center">
										<?php
										while($d=mysqli_fetch_array($result))
										{
											?>
                                        <tr>
											<form method="post">
                                        	<td><?php echo $d['bm_id']; ?></td>
                                        	<td><?php echo $d['um_name']; ?></td>
                                            <td> <?php echo $d['pm_pumpname'];  ?> </td>
                                        	<td><?php echo $d['lm_id']; ?></td>
											<td> <?php echo $d['bm_date'];  ?> </td>
                                            <td> <?php echo $d['bm_time'];  ?> </td>
                                            <td> <?php echo $d['bm_percent'];  ?> </td>
                                            <td> <?php echo $d['bm_price'];  ?> </td>
                                            <td> <?php echo $d['bm_totalPrice'];  ?> </td>
                                            <td> <?php echo $d['bm_vehicleNo'];  ?> </td>
											<td> 
												<span id="status_<?php echo $d['bm_id'] ?>">
												<?php echo $d['bm_status'];  ?> </span>
												<select name="newStatus" id="updateStatus_<?php echo $d['bm_id']?>" style="display:none">
													<option value="Booked" <?php $d['bm_status']=="Booked"? print "selected":"" ?>>Booked</option>
													<option value="Completed" <?php $d['bm_status']=="Completed"? print "selected":"" ?> >Completed</option>
													<option value="Cancel" <?php $d['bm_status']=="Cancel"? print "selected":"" ?> >Cancel</option>
													<option value="Running" <?php $d['bm_status']=="Running"? print "selected":"" ?> >Running</option>
													<option value="Reject" <?php $d['bm_status']=="Reject"? print "selected":"" ?> >Reject</option>
												</select>
												<input type="hidden" name="recordId" value="<?php echo $d['bm_id'] ?>">
											</td>
                                        	
												<td> 
	
												<div class="btn-group">
												  <button type="button" id="btnEdit_<?php echo $d['bm_id']; ?>" onclick="updateRecord('<?php echo $d['bm_id'] ?>');" class="btn btn-info btn-sm"><i class="fa fa-edit"></i></button>
												  <button type="submit" name="btnSave" style="display:none;" id="btnSave_<?php echo $d['bm_id']; ?>" class="btn btn-info btn-sm"><i class="fa fa-save"></i></button>
												</div> 
												</td>
										</form>
                                        </tr>
									<?php
										}
									?>
									
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
						
						
					<!-- </div>
				</div>
 -->

				
<script src="/efueladmin/js/jquery.min.js"></script>

<script>
	$("#profiledd").click(function(){
		if($("#profiledd").hasClass("open"))
	{
		$("#profiledd").removeClass("open");
	}
	else{
		$("#profiledd").addClass("open");
	}
	});
	</script>
<script>
	function updateRecord(id){
		$("#status_"+id).hide();
		$("#updateStatus_"+id).show();
		$("#btnEdit_"+id).hide();
		$("#btnSave_"+id).show();
	}
</script>
<?php
include "./layout/dbfooter.php";
?>

