<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
    header("location: ../dblogin.php");
}

$id=$_GET['id'];
$query="SELECT * FROM ef_pointmaster WHERE pt_id = $id";
$result = mysqli_query($conn,$query);
$getData = mysqli_fetch_array($result);

$pumpQuery = "SELECT * FROM ef_pumpmaster";
$pumpResult = mysqli_query($conn,$pumpQuery);

$levelQuery = "SELECT * FROM ef_levelmaster";
$levelResult = mysqli_query($conn,$levelQuery);
$levelData=mysqli_fetch_array($levelResult);

$types = explode(",",$levelData['lm_name']);

if(isset(($_POST['submit'])))
{
    //$lmid=$_POST['lmid'];
    $pmid=$_POST['pmid'];
    $available=$_POST['available'];
	$price=$_POST['price'];
	$type = implode(",",$_POST['vehicleType']);
    $status=0;
    if(isset($_POST['status']))
    {
        $status=1;
    }

    $query1="UPDATE ef_pointmaster SET lm_id='$type',pm_id='$pmid',pt_available=$available,pt_price=$price,
    pt_status=$status WHERE pt_id=$id";
    
    $result1=mysqli_query($conn,$query1);
    if($result1==1)
    {
        header("location: pntindex.php");
    }
    else
    {
        $errorMessage="Oops!!Something went wrong..";
    }
}
$pageHeading="Slot";
include("../layout/dbheader.php");
?>

<div class="content">
					<div class="container-fluid">
					
						<div class="row" style="margin: 10px 0;">
						
							<div class="col-md-12">
							
								<div class="card" style="margin-bottom:100px;">
								
									<div class="header">
										<h4 class="title">Update Slot</h4>
										<!--<p class="category">Here is a subtitle for this table</p><br>-->
										
									</div>
									
									<div class="form">
									
										<form role="form" method="post" class="row">
										
                                        <div class="col-md-6 form-group">
                                            <!--<label for="exampleInputEmail1">Level</label>-->
                                             <!--<input type="text" name="lmid" value="<?php //echo $getData['lm_id']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">-->

											

                                           <!-- <select name="lmid" class="form-control">
												<?php
												//while($l = mysqli_fetch_array($levelResult))
												//{
													?>
													<option value="<?php //echo $l['lm_id']; ?>"><?php //echo $l['lm_name']; ?></option>
													<?php
												//}
												?>
											</select>-->
												
											<div class="col-md-6 form-group">
                                            <label for="exampleInputPassword1">Level</label>
											<?php //echo $levelData['lm_id']; ?>
											<!--<select name="lmid" class="form-control">-->
											<?php
												while($l = mysqli_fetch_array($levelResult))
												{
													?>
													<input type="checkbox" name="vehicleType[]" value="<?php echo $l['lm_id']; ?>"> <?php echo $l['lm_name']; ?>&nbsp;
													<?php
												}
												?>
												</div>
                                        
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Pump Name</label>
                                            <!-- <input type="text" name="pmid" value="<?php echo $getData['pm_id']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"> -->
                                            <select name="pmid" class="form-control">
												<?php
												while($p = mysqli_fetch_array($pumpResult))
												{
													?>
													<option value="<?php echo $p['pmId']; ?>"><?php echo $p['pm_pumpname']; ?></option>
													<?php
												}
												?>
											</select>
                                        </div>

                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Slot Availability</label>
                                            <input type="text" name="available" value="<?php echo $getData['pt_available']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>

										<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Price</label>
                                            <input type="text" name="price" value="<?php echo $getData['pt_price']; ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                                        </div>

										<!--<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Type</label>
                                            <select class="form-control">
												<option>Select User Type</option>
												<option>Candidate</option>
												<option>Instructor</option>
												<option>Demo</option>
											</select>
                                        </div>-->
										
										<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Status</label>
                                            <input type="checkbox" name="status" value="1" class="" id="exampleInputEmail1" aria-describedby="emailHelp" <?php $getData['pt_status']==1 ? print 'checked' : '' ; ?>>
                                            
                                        </div>
										
										<div class="col-md-12 text-danger">
											<h6>
												<?php
												if(isset($errorMessage))
												{
													echo $errorMessage;
												}
												?>
											</h6>
										</div>
                                           <!-- <label for="exampleInputEmail1">Action</label>
                                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >-->
                                            
                                        
										
										
										<div class="col-md-12 form-group">
											<button type="submit" name="submit" class="btn btn-warning btn-lg">Update</button>
										</div>
										
                                    </form>
									</div>
								
								</div>
							
							</div>
							
						</div>
						
						
					</div>
				</div>
<?php
include "../layout/dbfooter.php";
?>