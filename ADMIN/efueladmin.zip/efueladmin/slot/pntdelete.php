<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
    header("Location: ../dblogin.php");
}
$deleteId = $_GET['id'];
$query="DELETE FROM ef_pointmaster WHERE pt_Id=$deleteId";
$result=mysqli_query($conn,$query);
header("location: ../slot/pntindex.php");
?>