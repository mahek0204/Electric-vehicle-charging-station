<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
	header("Location: ../dblogin.php");
}

$query="SELECT * FROM ef_pointmaster 
INNER JOIN ef_levelmaster on ef_pointmaster.lm_id = ef_levelmaster.lm_id
INNER JOIN ef_pumpmaster on ef_pumpmaster.pmId = ef_pointmaster.pm_id";

$result=mysqli_query($conn,$query);

$pageHeading="Slot";
include "../layout/dbheader.php";
?>
					
						<div class="row">
                    <div class="col-md-12">
                        <div class="card" style="margin-bottom:100px;">
                            <div class="header" style="display:flex;">
                                <h4 class="title" style="width:90%">Slots</h4>
                               <!-- <p class="category">Here is a subtitle for this table</p>-->
								 <a href="pntcreate.php" class="btn btn-warning"><i class="fa fa-plus"></i>&nbsp; Create</a> 
                            </div>
                            <div class="content table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
											<th class="text-center">Level</th>
											<th class="text-center">Pump name</th>
											<th class="text-center">Slot Availability</th>
											<th class="text-center">Pricing</th>
                                            <th class="text-center">Status</th>
											<th class="text-center">Action</th>
										</tr>
									</thead>
                                    <tbody class="text-center">
										<?php
										while($d=mysqli_fetch_array($result))
										{
											?>
                                        <tr>
                                        	<td><?php echo $d['lm_name']; ?></td>
                                        	<td><?php echo $d['pm_pumpname']; ?></td>
                                        	<td><?php echo $d['pt_available']; ?></td>
											<td><?php echo $d['pt_price']; ?></td>
                                          
                                        	<td>
												<?php
												if($d['pt_status']==1)
												{
													echo "<span class='label label-success'>Active</span>";
												}
												else
												{
													echo "<span class='label label-danger'>De-Active</span>";
												}
												?>
												</td>
												<td> 
	
												<div class="btn-group">
												  <a href="pntedit.php?id=<?php echo $d['pt_id']; ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i></a>
												  <!--<a href="#" class="btn btn-warning btn-sm"><i class="fa fa-book"></i></a>-->
												  <a href="pntdelete.php?id=<?php echo $d['pt_id']; ?>" onclick="return confirm('Are you sure you want to delete ?');" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
												</div> 
												</td>
                                        </tr>
										<?php
										}
										?>
											
                                        	
                                        
                                    </tbody>
									
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
						
						
					</div>
				</div>


<?php
include "../layout/dbfooter.php";
?>