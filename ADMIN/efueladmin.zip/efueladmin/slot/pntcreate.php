<?php
require('../connection.php');
if(!isset($_COOKIE['adminname']))
{
	header("location: ../dblogin.php");
}

$pumpQuery = "SELECT * FROM ef_pumpmaster";
$pumpResult = mysqli_query($conn,$pumpQuery);

$levelQuery = "SELECT * FROM ef_levelmaster";
$levelResult = mysqli_query($conn,$levelQuery);

$errorMessage;

if(isset($_POST['submit']))
{
	$p_name=$_POST['pump'];
	//$level=$_POST['level'];
	$slot=$_POST['slots'];
    $price=$_POST['price'];
	$type = implode(",",$_POST['vehicleType']);
	$status=0;

	if(isset($_POST['status']))
	{
		$status=1;
	}

	$query="INSERT INTO ef_pointmaster (lm_id,pm_id,pt_available,pt_price,pt_status) VALUES ('$type',$p_name,$slot,$price,$status)";
	$result=mysqli_query($conn,$query);
	if($result==1)
	{
		header("Location: pntindex.php");
	}
	else
	{
		$errorMessage="Oops!! Something went wrong..!";
	}
}
$pageHeading="Slot";
include "../layout/dbheader.php";
?>


				<div class="content">
					<div class="container-fluid">
					
						<div class="row" style="margin: 10px 0;">
						
							<div class="col-md-12">
							
								<div class="card" style="margin-bottom:100px;">
								
									<div class="header">
										<h4 class="title">Create Point</h4>
										<!--<p class="category">Here is a subtitle for this table</p><br>-->	
									</div>
									
									<div class="form">
									
										<form role="form" class="row" method="post">
										
                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Pump</label>
                                            <!-- <input type="text" name="pump" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"> -->
                                            <select name="pump" class="form-control">
												<?php 
												while($p = mysqli_fetch_array($pumpResult))
												{
													?>
													<option value="<?php echo $p['pmId']; ?>"><?php echo $p['pm_pumpname']; ?></option>
													<?php
												}
												?>
											</select>
                                        </div>	
                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputPassword1">Level</label>
												<!-- <div class="col-md-2 form-group">
                        <label for="exampleInputPassword1">Level</label> -->
                                <!-- <input type="text" name="level" class="form-control" id="exampleInputPassword1">-->
								<select name="level" required class="form-control">
										<?php
											while($l = mysqli_fetch_array($levelResult))
											{
											?>
											<option value="<?php echo $l['lm_id']; ?>"><?php echo $l['lm_name']; ?></option>
											<?php
											}
											?>
										</select>
										</div>
											
												
                                           <!-- <input type="text" name="level" class="form-control" id="exampleInputPassword1">-->
										   <!--<select name="level" class="form-control">-->
												

												<!--<div class="col-md-6 form-group">
												<label for="exampleInputPassword1">Vehicle Type</label>
												<input type="text" name="vehicleType" class="form-control" id="exampleInputPassword1">
											</div>-->
											
											<!--<div class="col-md-6 form-group">
												<label for="exampleInputEmail1">Level</label>
												<input type="checkbox" value="2 Wheeler" class="" name="vehicleType[]"  id="exampleInputEmail1" aria-describedby="emailHelp">  Level 1 &nbsp;
												<input type="checkbox" value="3 Wheeler" class="" name="vehicleType[]"  id="exampleInputEmail1" aria-describedby="emailHelp">  Level 2 &nbsp;
												<input type="checkbox" value="4 Wheeler" class="" name="vehicleType[]"  id="exampleInputEmail1" aria-describedby="emailHelp">  Level 3 &nbsp;
											</select>
                                        	</div>-->
										
										<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Slot Available</label>
											<input type="text" name="slots" class="form-control" id="exampleInputPassword1">
                                        
                                        </div>

										<div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Price</label>
											<input type="text" name="price" class="form-control" id="exampleInputPassword1">
                                        </div>
										
										
										
										
                                        <div class="col-md-6 form-group">
                                            <label for="exampleInputEmail1">Status</label>
                                            <input type="checkbox" value="1" class="" name="status" checked id="exampleInputEmail1" aria-describedby="emailHelp">
                                            
                                        </div>

										<div class="col-md-12 text-danger">
											<h6>
												<?php
												if(isset($errorMessage))
												{
													echo $errorMessage;
												}
												?>
											</h6>
										</div>
                                           <!-- <label for="exampleInputEmail1">Action</label>
                                            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >-->
                                            
										
										<div class="col-md-12 form-group">
											<button type="submit" name="submit" class="btn btn-warning btn-lg">Submit</button>
										</div>
										</div>
                                    </form>
									</div>
								
								</div>
							
							</div>
							
						</div>
						
						
					</div>
				</div>
<?php
include "../layout/dbfooter.php";
?>





