<?php
$conn = mysqli_connect("localhost","root","","efuel_db");
?>