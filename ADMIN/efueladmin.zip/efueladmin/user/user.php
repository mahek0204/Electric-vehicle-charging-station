
<?php
require("../connection.php");
if(!isset($_COOKIE['adminname']))
{
	header("Location: index.php");
}

$query="SELECT * FROM ef_usermaster";
$result=mysqli_query($conn,$query);
$pageHeading="User's Information";
include "../layout/dbheader.php";

?>



				
						
						<div class="row">
                    <div class="col-md-12">
                        <div class="card" style="margin-bottom:100px;">
                            <div class="header style=" style="display:flex;">
                                <h4 class="title" style="width:90%">User's Information</h4>
                               <!-- <p class="category">Here is a subtitle for this table</p>-->
								 
                            </div>
                            <div class="content table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
											<th class="text-center">Name</th>
											<th class="text-center">Email</th>
											<th class="text-center">Contact No</th>
											
										</tr>
									</thead>
                                    <tbody class="text-center">
										<?php
										while($d=mysqli_fetch_array($result))
										{
											?>
                                        <tr>
                                        	<td><?php echo $d['um_name']; ?></td>
                                        	<td><?php echo $d['um_email']; ?></td>
                                        	<td> <?php echo $d['um_contactNo'];  ?> 
                                        </td>
                                            
                                        	 
	
												
												</td>
                                        </tr>
									<?php
										}
									?>
                                        
                                    </tbody>
									
                                </table>

                            </div>
                        </div>
                    </div>

                </div>
						
						
					</div>
				</div>


<?php
include "../layout/dbfooter.php";
?>