<footer class="footer last-ftr">
					<div class="container-fluid">
						
						<div class="copyright">
							© 2024  E Fuel. All Rights Reserved | Developed by Team </a>
						</div>
					</div>
				</footer>

			</div>

        </div>
        <!-- END wrapper -->

        <!-- jQuery  -->
        <script src="../js/jquery.min.js"></script>
        <script src="../js/popper.min.js"></script><!-- Popper for Bootstrap -->
        <script src="../js/bootstrap.min.js"></script>
		<script src="../js/dashboard.js"></script>
		
    </body>
</html>