<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="/efueladmin/image/f213.png">

        <title>E Fuel</title>

        
		<link rel="stylesheet" href="/efueladmin/css/font-awesome.min.css">
		<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
        <link href="/efueladmin/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
		<link href="/efueladmin/css/style.css" rel="stylesheet" type="text/css" /> 
		<link href="/https://demos.creative-tim.com/bs3/paper-dashboard/assets/css/themify-icons.css" rel="stylesheet">
    </head>

    <body class="fixed-left">

        <!-- Begin page -->
        <div class="wrapper">

			<div class="sidebar" id="bs-example-navbar-collapse-1" data-background-color="white" data-active-color="danger">
			<nav class="navbar navbar-default header">
				<div class="sidebar-wrapper">
					<div class="logo">
						<!--<a href="http://www.creative-tim.com" class="simple-text">-->
							<img src="/efueladmin/image\logo.png" height="80px">
						</a>
					</div>

					<ul class="nav">
					
						<li>
							<a href="/efueladmin/dbindex.php">
								<i class="fa fa-tachometer"></i>
								<p>Dashboard</p>
							</a>
						</li>
						<?php 
						if($_COOKIE['admintype']=="ADM" )
						{	
							?>
							<li>
							<a href="/efueladmin/pump/pindex.php">
								<i class="fa fa-plug"></i>
								<p>Pump</p>
							</a>
						</li>
							<li>
							<a href="/efueladmin/Level">
								<i class="fa fa-signal"></i>
								<p>Levels</p>
							</a>
						</li>
						
						<li>
							<a href="/efueladmin/slot/pntindex.php">
								<i class="fa fa-tasks"></i>
								<p>Slots</p>
							</a>
						</li>
						<li>
							<a href="/efueladmin/R&R/booking.php">
								<i class="fa solid fa-book"></i>
								<p>Bookings</p>
							</a>
						</li>
						<li>
							<a href="/efueladmin/user/user.php">
								<i class="fa solid fa-user"></i>
								<p>User</p>
							</a>
						</li>
						<li>
							<a href="/efueladmin/R&R/contactinquiry.php">
								<i class="fa fa-phone-square"></i>
								<p>Contact Inquiry</p>
							</a>
						</li>
						
						
						<li>
							<a href="/efueladmin/R&R/credit.php">
								<i class="fa fa-usd"></i>
								<p>Credit points</p>
							</a>
						</li>
						<li>
							<a href="/efueladmin/R&R/review.php">
								<i class="fa fa-pencil"></i>
								<p>Reviews</p>
							</a>
						</li>
						<li>
							<a href="/efueladmin/R&R/report.php">
								<i class="fa fa-line-chart"></i>
								<p>Reports</p>
							</a>
						</li>
							<?php
						}
						?>
						
						
					</ul>
				</div>
			</div>

            			
			
			
			<div class="main-panel">
				<nav class="navbar navbar-default header">
				  <div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					<button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
					
					  <!-- <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"> -->
						<!-- <span class="sr-only">Toggle navigation</span> -->
						<!-- <span class="icon-bar"></span> -->
						<!-- <span class="icon-bar"></span> -->
						<!-- <span class="icon-bar"></span> -->
					  <!-- </button> -->
					  <div>
                      <a class="navbar-brand n-brnd" href="#"><?php echo $pageHeading; ?></a>
                      </div>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse">
					  <ul class="nav navbar-nav navbar-right menu-right">
						<li id="profiledd" class="dropdown">
						  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true"><i class="fa fa-user"></i>&nbsp; <?php echo $_COOKIE['adminname']; ?> <span class="caret"></span></a>
						  <ul class="dropdown-menu">
							<li><a href="#">Profile</a></li>
							<li><a href="/efueladmin/logout.php">Logout</a></li>
							<!--<li><a href="#">Something else here</a></li>-->
							
						  </ul>
						</li>
						<!--<li><a href="#"><i class="ti-settings"></i>&nbsp; Settings</a></li>-->
					  </ul>
					</div><!-- /.navbar-collapse -->
					
				  </div><!-- /.container-fluid -->
				</nav>